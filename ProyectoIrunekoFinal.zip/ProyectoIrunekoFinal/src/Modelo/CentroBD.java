package Modelo;

import static Modelo.GenericoBD.abrirConexion;
import static Modelo.GenericoBD.cerrarConexion;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author 1gprog04
 */

public class CentroBD extends GenericoBD{
    
    private static Centro c;
    
    /**
     * Busca todos los Centros de la base de datos y los retorna
     * @return
     * @throws Exception 
     */
    public static ArrayList<Centro> buscarCentros() throws Exception{
        
            ArrayList<Centro> centros = new ArrayList();
        
            abrirConexion();
            
            Statement sentencia = GenericoBD.getCon().createStatement();
            ResultSet resultado = sentencia.executeQuery("SELECT * FROM Centro");
            while(resultado.next()){
                
                c = new Centro();
            
            c.setId_centro(resultado.getString("idcentro"));
            c.setNombre(resultado.getString("nombre"));
            c.setTlf_fijo(resultado.getString("tlf"));
            c.setCp(resultado.getString("cp"));
            c.setProvincia(resultado.getString("provincia"));
            c.setCiudad(resultado.getString("ciudad"));
            c.setCalle(resultado.getString("calle"));
            c.setNumero(resultado.getString("numero"));
            
            centros.add(c);
            }
            cerrarConexion();
            return centros;
                    
    }
        
    /**
     * Busca y retorna los datos de un centro en concreto
     * @param id
     * @return
     * @throws Exception 
     */    
    public static Centro buscarCentroID(String id) throws Exception{
        abrirConexion();
        
        String plantilla="SELECT * FROM Centro WHERE idcentro = ?";
        
        PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);
        ps.setString(1, id);
        ResultSet rs = ps.executeQuery();
        if (rs.next() == false)
        {
            c = null;
        }
        else
        {
            c = new Centro();
            
            c.setId_centro(rs.getString("idcentro"));
            c.setNombre(rs.getString("nombre"));
            c.setTlf_fijo(rs.getString("tlf"));
            c.setCp(rs.getString("cp"));
            c.setProvincia(rs.getString("provincia"));
            c.setCiudad(rs.getString("ciudad"));
            c.setCalle(rs.getString("calle"));
            c.setNumero(rs.getString("numero"));
        }
        
        cerrarConexion();
        return c;
    }
    
    /**
     * Borra de la base de datos un Centro
     * @param id
     * @throws Exception 
     */
    public static void borrar(String id)throws Exception{
        
            abrirConexion();  
            String plantilla;

            plantilla = "DELETE FROM Centro WHERE idcentro = ?";

            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);
            ps.setString(1, id);
             
            ps.executeUpdate();
            
            
            
            
            cerrarConexion();
            
        } 
    
        /**
         * Inserta un Centro en la base de datos
         * @param id
         * @param nom
         * @param fijo
         * @param codp
         * @param prov
         * @param ciu
         * @param cal
         * @param num
         * @throws Exception 
         */
        public static void insertar(String id, String nom, String fijo, String codp, String prov, String ciu, String cal, String num) throws Exception{
        
       
            GenericoBD.abrirConexion();   
            
            String plantilla;

            plantilla = "INSERT INTO Centro VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);
            ps.setString(1, id);
            ps.setString(2, nom);
            ps.setString(3, fijo);
            ps.setString(4, codp);
            ps.setString(5, prov);
            ps.setString(6, ciu);
            ps.setString(7, cal);
            ps.setString(8, num);
            
            ps.executeUpdate();
            
            
            cerrarConexion();
            
        }
        
        /**
         * Actualiza los datos de un Centro en la base de datos
         * @param nom
         * @param fijo
         * @param codp
         * @param prov
         * @param ciu
         * @param cal
         * @param num
         * @param id
         * @throws Exception 
         */
        public static void actualizar(String nom, String fijo, String codp, String prov, String ciu, String cal, String num, String id) throws Exception{
            abrirConexion();   
            String plantilla;

            plantilla = "UPDATE Centro SET  nombre = ?, tlf = ?, cp = ?, provincia = ?, ciudad = ?, calle = ?, numero = ? WHERE idcentro = ? ";

            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);
            ps.setString(1, nom);
            ps.setString(2, fijo);
            ps.setString(3, codp);
            ps.setString(4, prov);
            ps.setString(5, ciu);
            ps.setString(6, cal);
            ps.setString(7, num);
            
            ps.setString(8, id);
                       
            ps.executeUpdate();
            
          
            cerrarConexion();
            
            
        }
    
    
}
