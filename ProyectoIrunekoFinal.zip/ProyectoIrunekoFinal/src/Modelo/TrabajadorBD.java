package Modelo;

import static Modelo.GenericoBD.abrirConexion;
import static Modelo.GenericoBD.cerrarConexion;
import java.sql.*;
import java.util.ArrayList;
import java.util.Calendar;
import javax.swing.JOptionPane;

/**
 *
 * @author 1gprog04
 */


public class TrabajadorBD extends GenericoBD{
    
    private static Trabajador t;
    
    /**
     * Busca los Trabajadores de Logistica de un Centro y los retorna
     * @param id
     * @return
     * @throws Exception 
     */
    public static ArrayList<Trabajador> buscarporCentroyLogi(String id) throws Exception{
        
            ArrayList<Trabajador> trabajadores = new ArrayList();
        
            abrirConexion();
            String plantilla = "SELECT * FROM Trabajador WHERE idcentro = ? AND tipo = 'L'";
            
            PreparedStatement ps = getCon().prepareStatement(plantilla);
            ps.setString(1, id);
            ResultSet resultado = ps.executeQuery();
            
            
                while(resultado.next()){

                    t = new TransporteLogistica();

                t.setDni(resultado.getString("dni"));
            
            
                t.setNombre(resultado.getString("nombre"));
                t.setApellido1(resultado.getString("apellido1"));
                t.setApellido2(resultado.getString("apellido2"));
                t.setCalle(resultado.getString("calle"));
                t.setNumero(resultado.getString("numero"));
                t.setPiso(resultado.getString("piso"));
                t.setMano(resultado.getString("mano"));
                t.setTlf_empresa(resultado.getString("tlfempresa"));
                t.setTlf_personal(resultado.getString("tlfpersonal"));
                t.setFecha_nac(resultado.getDate("fechanac"));
                t.setSalario(resultado.getFloat("salario"));
                
                trabajadores.add(t);
                }
                
                
            
            cerrarConexion();
            return trabajadores;
                    
    }
    
    /**
     * Busca un Trabajador por su DNI y lo retorna
     * @param dni
     * @return
     * @throws Exception 
     */
    public static Trabajador buscarDni(String dni) throws Exception{
        
        
            abrirConexion();
            String plantilla="SELECT * FROM Trabajador WHERE dni = ?";

            PreparedStatement ps = getCon().prepareStatement(plantilla);
            ps.setString(1, dni);
            ResultSet resultado = ps.executeQuery();
            
            
            if (resultado.next() == false)
            {
                t = null;
            }
            else
            {
                if (resultado.getString("tipo").compareToIgnoreCase("A") == 0)
                {
                    t = new Administracion();
                }
                else
                {
                    t = new TransporteLogistica();
                }
                
                

                t.setDni(resultado.getString("dni"));
            
            
                t.setNombre(resultado.getString("nombre"));
                t.setApellido1(resultado.getString("apellido1"));
                t.setApellido2(resultado.getString("apellido2"));
                t.setCalle(resultado.getString("calle"));
                t.setNumero(resultado.getString("numero"));
                t.setPiso(resultado.getString("piso"));
                t.setMano(resultado.getString("mano"));
                t.setTlf_empresa(resultado.getString("tlfempresa"));
                t.setTlf_personal(resultado.getString("tlfpersonal"));
                t.setFecha_nac(resultado.getDate("fechanac"));
                t.setSalario(resultado.getFloat("salario"));
                Controlador.Main.setTipo(resultado.getString("tipo"));
                Controlador.Main.guardarCentro(resultado.getString("idcentro"));
                Controlador.Main.setUsuario(resultado.getString("usuario"));
                }
                
            cerrarConexion();
            return t;
        
        
    }
    
    /**
     * Busca todos los Trabajadores de un Centro y los retorna
     * @param id
     * @return
     * @throws Exception 
     */
    public static ArrayList<Trabajador> buscarporCentro(String id) throws Exception{
        
            ArrayList<Trabajador> trabajadores = new ArrayList();
        
            abrirConexion();
            String plantilla="SELECT * FROM Trabajador WHERE idcentro = ?";

            PreparedStatement ps = getCon().prepareStatement(plantilla);
            ps.setString(1, id);
            ResultSet resultado = ps.executeQuery();
            
            while(resultado.next()){
            
                if (resultado.getString("tipo").compareToIgnoreCase("A") == 0)
                {
                    t = new Administracion();
                }
                else
                {
                    t = new TransporteLogistica();
                }
                
                

                t.setDni(resultado.getString("dni"));
            
                t.setNombre(resultado.getString("nombre"));
                t.setApellido1(resultado.getString("apellido1"));
                t.setApellido2(resultado.getString("apellido2"));
                t.setCalle(resultado.getString("calle"));
                t.setNumero(resultado.getString("numero"));
                t.setPiso(resultado.getString("piso"));
                t.setMano(resultado.getString("mano"));
                t.setTlf_empresa(resultado.getString("tlfempresa"));
                t.setTlf_personal(resultado.getString("tlfpersonal"));
                t.setFecha_nac(resultado.getDate("fechanac"));
                t.setSalario(resultado.getFloat("salario"));
                
                trabajadores.add(t);
                
            }
                
            cerrarConexion();
            return trabajadores;
        
        
    }
    
    /**
     * 
     * @param usu
     * @return
     * @throws Exception 
     */
    public static Trabajador buscarporUsuario(String usu) throws Exception{
        
        
            abrirConexion();
            String plantilla="SELECT * FROM Trabajador WHERE usuario = ?";

            PreparedStatement ps = getCon().prepareStatement(plantilla);
            ps.setString(1, usu);
            ResultSet resultado = ps.executeQuery();
            
            
            if (resultado.next() == false)
            {
                t = null;
            }
            else
            {
                if (resultado.getString("tipo").compareToIgnoreCase("A") == 0)
                {
                    t = new Administracion();
                }
                else
                {
                    t = new TransporteLogistica();
                }
                
                

                t.setDni(resultado.getString("dni"));
            
            
                t.setNombre(resultado.getString("nombre"));
                t.setApellido1(resultado.getString("apellido1"));
                t.setApellido2(resultado.getString("apellido2"));
                t.setCalle(resultado.getString("calle"));
                t.setNumero(resultado.getString("numero"));
                t.setPiso(resultado.getString("piso"));
                t.setMano(resultado.getString("mano"));
                t.setTlf_personal(resultado.getString("tlfpersonal"));
                t.setTlf_empresa(resultado.getString("tlfempresa"));
                t.setFecha_nac(resultado.getDate("fechanac"));
                t.setSalario(resultado.getFloat("salario"));
                Controlador.Main.setTipologged(resultado.getString("tipo"));
                Controlador.Main.guardarCentroLogged(resultado.getString("idcentro"));
                Controlador.Main.setUsuario(resultado.getString("usuario"));
                }
                
            cerrarConexion();
            return t;
        
        
    }
    
    /**
     * Borra a un Trabajador de la base de datos
     * @param dni
     * @throws Exception 
     */
    public static void borrar(String dni)throws Exception{
        
            abrirConexion();  
            String plantilla;

            plantilla = "DELETE FROM Trabajador WHERE dni = ?";

            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);
            ps.setString(1, dni);
             
            ps.executeUpdate();
            
            
            cerrarConexion();
            
        }     
        
    
    /**
     * Actualiza a un Trabajador de la base de datos
     * @param nom
     * @param ape1
     * @param ape2
     * @param calle
     * @param num
     * @param piso
     * @param mano
     * @param emp
     * @param per
     * @param fech
     * @param sal
     * @param tipo
     * @param centro
     * @param dni
     * @throws Exception 
     */
    public static void actualizar(String nom, String ape1, String ape2, String calle, String num, String piso, String mano, String emp, String per,Calendar fech, Float sal, String tipo, String centro, String dni) throws Exception{
            abrirConexion();   
            String plantilla;

            plantilla = "UPDATE Trabajador SET nombre = ?, apellido1= ?, apellido2 = ?, calle = ?, numero = ?, piso = ?, mano = ?, tlfempresa = ?, tlfpersonal = ?, fechanac = ?, salario = ?, tipo = ?, idcentro = ? WHERE dni= ? ";

            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);
            ps.setString(1, nom);
            ps.setString(2, ape1);
            ps.setString(3, ape2);
            ps.setString(4, calle);
            ps.setString(5, num);
            ps.setString(6, piso);
            ps.setString(7, mano);
            ps.setString(8, emp);
            ps.setString(9, per);
           
            java.sql.Date fec = new java.sql.Date(fech.getTime().getTime());
            ps.setDate(10, fec);
            
            ps.setFloat(11, sal);
            ps.setString(12, tipo);
            ps.setString(13, centro);
            
            ps.setString(14, dni);
            ps.executeUpdate();
            
          
            cerrarConexion();
            
            
        }
        /**
         * Actualiza el usuario de un Trabajador de la base de datos
         * @param usuario
         * @param dni
         * @throws Exception 
         */
    public static void actualizarUsuario(String usuario, String dni) throws Exception{
            abrirConexion();   
            String plantilla;

            plantilla = "UPDATE Trabajador SET usuario = ? WHERE dni= ? ";

            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);
            
            
            ps.setString(1, usuario);
            
            ps.setString(2, dni);
            ps.executeUpdate();
            
          
            cerrarConexion();
            
            
        }
    
    /**
     * Inserta a un Trabajador en la base de datos
     * @param dni
     * @param nom
     * @param ape1
     * @param ape2
     * @param calle
     * @param num
     * @param piso
     * @param mano
     * @param emp
     * @param per
     * @param fech
     * @param sal
     * @param tipo
     * @param centro
     * @param usuario
     * @throws Exception 
     */
    public static void insertar(String dni, String nom, String ape1, String ape2, String calle, String num, String piso, String mano, String emp, String per,Calendar fech, Float sal, String tipo, String centro, String usuario) throws Exception{
        
       
            GenericoBD.abrirConexion();   
            
            String plantilla;

            plantilla = "INSERT INTO Trabajador VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);
            ps.setString(1, dni);
            ps.setString(2, nom);
            ps.setString(3, ape1);
            ps.setString(4, ape2);
            ps.setString(5, calle);
            ps.setString(6, num);
            ps.setString(7, piso);
            ps.setString(8, mano);
            ps.setString(9, emp);
            ps.setString(10, per);
            
            java.sql.Date fec = new java.sql.Date(fech.getTime().getTime());
            ps.setDate(11, fec);
            
            ps.setFloat(12, sal);
            ps.setString(13, tipo);
            ps.setString(14, centro);
            ps.setString(15, usuario);

            ps.executeUpdate();
            
            
            cerrarConexion();
        
        
            
        }
        
    }
