package Modelo;

import java.sql.*;

/**
 *
 * @author 1gprog04
 */

public class GenericoBD {
        private static Connection con;

    public static Connection getCon() {
        return con;
    }
        
    public static boolean abrirConexion(){
        
        try{
            
            Class.forName("oracle.jdbc.OracleDriver");
            String user = "daw04";
            String pass = "daw04";
            String url = "jdbc:oracle:thin:@SrvOracle:1521:orcl";
            
            con = DriverManager . getConnection (url ,user ,pass);
            
            return true;
            
        }
        catch(Exception e){
            System.out.println("Problemas " + e.getMessage());
            return false;
        }
    }
    
    public static boolean cerrarConexion(){
        try{
            con.close();            
            return true;
        }
        catch(Exception e){
            return false;
        }
        
    }

}


/* CONEXION DESDE CASA
            Class.forName("oracle.jdbc.OracleDriver");
            String user = "system";
            String pass = "oracle";
            String url = "jdbc:oracle:thin:@10.10.10.9:1521:db12102";

*/

/* CONEXION DESDE CLASE
            Class.forName("oracle.jdbc.OracleDriver");
            String user = "daw04";
            String pass = "daw04";
            String url = "jdbc:oracle:thin:@SrvOracle:1521:orcl";

*/