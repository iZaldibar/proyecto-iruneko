package Modelo;

import static Modelo.GenericoBD.abrirConexion;
import static Modelo.GenericoBD.cerrarConexion;
import java.sql.*;
import java.util.ArrayList;
import java.util.Calendar;

/**
 *
 * @author 1gprog04
 */
public class ParteBD extends GenericoBD{
    
    private static Parte p;
    
    /**
     * Busca todos los Partes de un Trabajador por su DNI y los retorna
     * @param dni
     * @return
     * @throws Exception 
     */
    public static ArrayList<Parte> buscarporDNI(String dni)throws Exception{
            
            ArrayList<Parte> partes = new ArrayList();
        
            abrirConexion();
        
            String plantilla = "SELECT * FROM Parte WHERE dni = ?";
            
            PreparedStatement ps = getCon().prepareStatement(plantilla);
            ps.setString(1, dni);
            ResultSet resultado = ps.executeQuery();
            
           
            
            while(resultado.next()){
                 p = new Parte();
                
                p.setIdparte(resultado.getString("idparte"));
                p.setFecha(resultado.getDate("fechaini"));
                p.setKmini(resultado.getInt("kminicio"));
                p.setKmfin(resultado.getInt("kmfin"));
                p.setGasoil(resultado.getFloat("gasoil"));
                p.setAutopista(resultado.getFloat("autopista"));
                p.setDieta(resultado.getFloat("dieta"));
                p.setOtros_gastos(resultado.getFloat("otros"));
                p.setIncidencias(resultado.getString("incidencias"));
                p.setEstado(resultado.getString("estado"));
                p.setValidado(resultado.getString("validado"));
                
                partes.add(p);
            }
                
            cerrarConexion();
            return partes;
    }

    /**
     * Busca todos los Partes de un Trabajador entre ciertas fechas y los retorna
     * @param dni
     * @param fech1
     * @param fech2
     * @return
     * @throws Exception 
     */
    public static ArrayList<Parte> buscarporDNIfechas(String dni, Calendar fech1, Calendar fech2) throws Exception{
            
            abrirConexion();
            
            ArrayList<Parte> partes = new ArrayList();
        
            String plantilla = "SELECT * FROM Parte WHERE dni = ? and fechaini BETWEEN ? AND ?";
            
            PreparedStatement ps = getCon().prepareStatement(plantilla);
            ps.setString(1, dni);
            
            java.sql.Date fec1 = new java.sql.Date(fech1.getTime().getTime());
            ps.setDate(2, fec1);
            
            java.sql.Date fec2 = new java.sql.Date(fech2.getTime().getTime());
            ps.setDate(3, fec2);
                    
            ResultSet resultado = ps.executeQuery();
            
            p = new Parte();
            
            while(resultado.next()){
                p.setIdparte(resultado.getString("idparte"));
                p.setFecha(resultado.getDate("fechaini"));
                p.setKmini(resultado.getInt("kminicio"));
                p.setKmfin(resultado.getInt("kmfin"));
                p.setGasoil(resultado.getFloat("gasoil"));
                p.setAutopista(resultado.getFloat("autopista"));
                p.setDieta(resultado.getFloat("dieta"));
                p.setOtros_gastos(resultado.getFloat("otros"));
                p.setIncidencias(resultado.getString("incidencias"));
                p.setEstado(resultado.getString("estado"));
                p.setValidado(resultado.getString("validado"));
                
                partes.add(p);
            }
                
            cerrarConexion();
            return partes;
    }
    
    /**
     * Busca un Parte por su ID y lo retorna
     * @param id
     * @return
     * @throws Exception 
     */
    public static Parte buscarID(String id) throws Exception{
        
        
            abrirConexion();
            String plantilla="SELECT * FROM Parte where idparte = ?";

            PreparedStatement ps = getCon().prepareStatement(plantilla);
            ps.setString(1, id);
            ResultSet resultado = ps.executeQuery();
            
            p = new Parte();
            
            if (resultado.next() == false)
            {
                p = null;
            }
            else
            {
                p.setIdparte(resultado.getString("idparte"));
                p.setFecha(resultado.getDate("fechaini"));
                p.setKmini(resultado.getInt("kminicio"));
                p.setKmfin(resultado.getInt("kmfin"));
                p.setGasoil(resultado.getFloat("gasoil"));
                p.setAutopista(resultado.getFloat("autopista"));
                p.setDieta(resultado.getFloat("dieta"));
                p.setOtros_gastos(resultado.getFloat("otros"));
                p.setIncidencias(resultado.getString("incidencias"));
                p.setEstado(resultado.getString("estado"));
                p.setValidado(resultado.getString("validado"));
                }
                
            cerrarConexion();
            return p;
        
        
    }
    
    public static ArrayList<Parte> buscarAbiertos(String dni) throws Exception{
        ArrayList<Parte> partes = new ArrayList();
        
            abrirConexion();
        
            String plantilla = "SELECT * FROM Parte WHERE dni = ? and estado = 'Abierto'";
            
            PreparedStatement ps = getCon().prepareStatement(plantilla);
            ps.setString(1, dni);
            ResultSet resultado = ps.executeQuery();
            
            
            
            while(resultado.next()){
                p = new Parte();
                
                p.setIdparte(resultado.getString("idparte"));
                p.setFecha(resultado.getDate("fechaini"));
                p.setKmini(resultado.getInt("kminicio"));
                p.setKmfin(resultado.getInt("kmfin"));
                p.setGasoil(resultado.getFloat("gasoil"));
                p.setAutopista(resultado.getFloat("autopista"));
                p.setDieta(resultado.getFloat("dieta"));
                p.setOtros_gastos(resultado.getFloat("otros"));
                p.setIncidencias(resultado.getString("incidencias"));
                p.setEstado(resultado.getString("estado"));
                p.setValidado(resultado.getString("validado"));
                
                partes.add(p);
            }
                
            cerrarConexion();
            return partes;
    }
    
    /**
     * Actualiza el estado de un Parte como cerrado
     * @param id
     * @throws Exception 
     */
    public static void cerrarParte(String id)throws Exception{
            abrirConexion();   
            String plantilla;

            plantilla = "UPDATE Parte SET estado = 'Cerrado' WHERE idparte = ? ";

            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);
            
            ps.setString(1, id);
                       
            ps.executeUpdate();
               
            cerrarConexion();
    }
    
    /**
     * Actualiza un Parte como validado
     * @param id
     * @throws Exception 
     */
    public static void validarParte(String id)throws Exception{
            abrirConexion();   
            String plantilla;

            plantilla = "UPDATE Parte SET validado = 'Si' WHERE idparte = ? ";

            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);
            
            ps.setString(1, id);
                       
            ps.executeUpdate();
                  
            cerrarConexion();

    }
    
    /**
     * Inserta un Parte en la base de datos
     * @param fecha
     * @param kminicio
     * @param kmfin
     * @param gasoil
     * @param auto
     * @param dieta
     * @param otros
     * @param incidencia
     * @param dni
     * @throws Exception 
     */
    public static void insertar(Calendar fecha, float kminicio, float kmfin, float gasoil, float auto, float dieta, float otros, String incidencia, String dni) throws Exception{
        
       
            GenericoBD.abrirConexion();   
            

            PreparedStatement ps = GenericoBD.getCon().prepareStatement("INSERT INTO Parte (fechaini, kminicio, kmfin, gasoil, autopista, dieta, otros, incidencias, estado, validado, dni) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Abierto','No' , ?)", new String[]{"idparte"});
            
            java.sql.Date feci = new java.sql.Date(fecha.getTime().getTime());
            ps.setDate(1, feci);
            
            
            ps.setFloat(2, kminicio);
            ps.setFloat(3, kmfin);
            ps.setFloat(4, gasoil);
            ps.setFloat(5, auto);
            ps.setFloat(6, dieta);
            ps.setFloat(7, otros);
            ps.setString(8, incidencia);
            ps.setString(9, dni);
            
            ps.executeUpdate();
            
            
            cerrarConexion();
            
        }
    
    /**
     * Actualiza los valores de un Parte de la base de datos
     * @param kminicio
     * @param kmfin
     * @param gasoil
     * @param auto
     * @param dieta
     * @param otros
     * @param incidencia
     * @param id
     * @throws Exception 
     */
    public static void actualizar(float kminicio, float kmfin, float gasoil, float auto, float dieta, float otros, String incidencia, String id) throws Exception{
        abrirConexion();   
            String plantilla;

            plantilla = "UPDATE Parte SET kminicio = ?, kmfin = ?, gasoil = ?, autopista = ?, dieta = ?, otros = ?, incidencias = ? WHERE idparte = ? ";

            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);
            
            ps.setFloat(1, kminicio);
            ps.setFloat(2, kmfin);
            ps.setFloat(3, gasoil);
            ps.setFloat(4, auto);
            ps.setFloat(5, dieta);
            ps.setFloat(6, otros);
            ps.setString(7, incidencia);
            ps.setString(8, id);
                       
            ps.executeUpdate();
            
          
            cerrarConexion();
    }
    
    /**
     * Borra un Parte de la base de datos
     * @param id
     * @throws Exception 
     */
    public static void borrar(String id)throws Exception{
        abrirConexion();   
            String plantilla;

            plantilla = "DELETE FROM Parte WHERE idparte = ? ";

            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);

            ps.setString(1, id);
                       
            ps.executeUpdate();
            
          
            cerrarConexion();
    }
    
    
    
}
