package Modelo;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author 1gprog04
 */
public class Parte {
    
    private String idparte;
    private Date fecha;
    private Integer kmini;
    private Integer kmfin;
    private float gasoil;
    private float autopista;
    private float dieta;
    private float otros_gastos;
    private String incidencias;
    private String estado;
    private String validado;
    
    private ArrayList<Viaje> viajes;

    public Parte() {
    }

    public String getIdparte() {
        return idparte;
    }

    public void setIdparte(String idparte) {
        this.idparte = idparte;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public float getKmini() {
        return kmini;
    }

    public void setKmini(Integer kmini) {
        this.kmini = kmini;
    }

    public float getKmfin() {
        return kmfin;
    }

    public void setKmfin(Integer kmfin) {
        this.kmfin = kmfin;
    }

    public float getGasoil() {
        return gasoil;
    }

    public void setGasoil(float gasoil) {
        this.gasoil = gasoil;
    }

    public float getAutopista() {
        return autopista;
    }

    public void setAutopista(float autopista) {
        this.autopista = autopista;
    }

    public float getDieta() {
        return dieta;
    }

    public void setDieta(float dieta) {
        this.dieta = dieta;
    }

    public float getOtros_gastos() {
        return otros_gastos;
    }

    public void setOtros_gastos(float otros_gastos) {
        this.otros_gastos = otros_gastos;
    }

    public String getIncidencias() {
        return incidencias;
    }

    public void setIncidencias(String incidencias) {
        this.incidencias = incidencias;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getValidado() {
        return validado;
    }

    public void setValidado(String validado) {
        this.validado = validado;
    }
    
    public ArrayList<Viaje> getViajes() throws Exception{
        viajes = ViajeBD.buscarViajesIDParte(idparte);
        return viajes;
    }
    
    
}
