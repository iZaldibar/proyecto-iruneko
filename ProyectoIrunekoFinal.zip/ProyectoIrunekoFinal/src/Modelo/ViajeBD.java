package Modelo;

import static Modelo.GenericoBD.abrirConexion;
import static Modelo.GenericoBD.cerrarConexion;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author 1gprog04
 */
public class ViajeBD extends GenericoBD{
    
    private static Viaje v; 
    
    /**
     * Busca todos los Viajes de un Parte
     * @param id
     * @return
     * @throws Exception 
     */
    public static ArrayList<Viaje> buscarViajesIDParte(String id)throws Exception{
            
            ArrayList<Viaje> viajes = new ArrayList();
        
            abrirConexion();
        
            String plantilla = "SELECT * FROM Viaje WHERE idparte = ?";
            
            PreparedStatement ps = getCon().prepareStatement(plantilla);
            ps.setString(1, id);
            ResultSet resultado = ps.executeQuery();
            
            while(resultado.next()){
                
                v = new Viaje();
                
                v.setAlbaran(resultado.getString("albaran"));
                v.setHorasalida(resultado.getString("horasalida"));
                v.setHorallegada(resultado.getString("horallegada"));
                v.setVehiculo(resultado.getString("vehiculo"));
                
                viajes.add(v);
            }
                
            cerrarConexion();
            return viajes;
    }
    
        
    /**
     * Busca un Viaje por su albaran
     * @param albaran
     * @return
     * @throws Exception 
     */    
    public static Viaje buscarViajeID(String albaran) throws Exception{
        abrirConexion();
        
        String plantilla="SELECT * FROM Viaje WHERE albaran = ?";
        
        PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);
        ps.setString(1, albaran);
        ResultSet rs = ps.executeQuery();
        if (rs.next() == false)
            {
                v = null;
        }
        else
        {
            v = new Viaje();
            
            v.setAlbaran(rs.getString("albaran"));
            v.setHorasalida(rs.getString("horasalida"));
            v.setHorallegada(rs.getString("horallegada"));
            v.setVehiculo(rs.getString("vehiculo"));
        }
        cerrarConexion();
        return v;
    }
    
    /**
     * Borra a un usuario de la base de datos
     * @param id
     * @throws Exception 
     */
    public static void borrar(String id)throws Exception{
        
            abrirConexion();  
            String plantilla;

            plantilla = "DELETE FROM Viaje WHERE albaran = ?";

            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);
            ps.setString(1, id);
             
            ps.executeUpdate();
            
            
            
            
            cerrarConexion();
            
        } 
    
    /**
     * Inserta un Viaje en la base de datos
     * @param horasal
     * @param horalle
     * @param idparte
     * @param vehiculo
     * @throws Exception 
     */
        public static void insertar(String horasal, String horalle, String idparte, String vehiculo) throws Exception{
        
       
            GenericoBD.abrirConexion();   
            

            PreparedStatement ps = GenericoBD.getCon().prepareStatement("INSERT INTO Viaje (horasalida, horallegada, idparte, vehiculo) VALUES (?, ?, ?, ?)", new String[]{"albaran"});
            ps.setString(1, horasal);
            ps.setString(2, horalle);
            ps.setString(3, idparte);
            ps.setString(4, vehiculo);
            
            ps.executeUpdate();
            
            
            cerrarConexion();
            
        }
        
        /**
         * Actualiza un Viaje de la base de datos
         * @param horasal
         * @param horalle
         * @param vehiculo
         * @param albaran
         * @throws Exception 
         */
        public static void actualizar(String horasal, String horalle,  String vehiculo, String albaran) throws Exception{
            abrirConexion();   
            String plantilla;

            plantilla = "UPDATE Viaje SET horasalida = ?, horallegada = ?, vehiculo = ? WHERE albaran = ?";

            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);
            
            ps.setString(1, horasal);
            ps.setString(2, horalle);
            ps.setString(3, vehiculo);
            ps.setString(4, albaran);
                       
            ps.executeUpdate();
            
          
            cerrarConexion();
            
            
        }
    
}
