
package Modelo;

import java.sql.*;

/**
 *
 * @author 1gprog04
 */
public class LoginBD extends GenericoBD{
        
        private static Login l;
        
        
        /**
         * Busca el usuario  de Login con los datos introducidos para saber si existe en la base de datos
         * @param usu
         * @param pass
         * @return
         * @throws Exception 
         */
        public static Login loginUsuario(String usu, String pass) throws Exception{


                abrirConexion();
                String plantilla="SELECT * FROM Login WHERE usuario = ? AND contrasena = ?";

                PreparedStatement ps = getCon().prepareStatement(plantilla);
                ps.setString(1, usu);
                ps.setString(2, pass);
                ResultSet resultado = ps.executeQuery();


                if (resultado.next() == false)
                {
                    l = null;
                }
                else
                {
                    l = new Login();
                    l.setUsuario(resultado.getString("usuario"));
                    l.setContrasena(resultado.getString("contrasena"));
                }

                cerrarConexion();
                return l;
        
        }
        
        /**
         * Busca un usuario de Login por su nombre de usuario
         * @param usu
         * @return
         * @throws Exception 
         */
        public static Login buscarUsuario(String usu) throws Exception{


                abrirConexion();
                String plantilla="SELECT * FROM Login WHERE usuario = ?";

                PreparedStatement ps = getCon().prepareStatement(plantilla);
                ps.setString(1, usu);
                ResultSet resultado = ps.executeQuery();


                if (resultado.next() == false)
                {
                    l = null;
                }
                else
                {
                    l = new Login();
                    l.setUsuario(resultado.getString("usuario"));
                    l.setContrasena(resultado.getString("contrasena"));
                }

                cerrarConexion();
                return l;
        
        }
        
        /**
         * Inserta un usuario de Login en la base de datos
         * @param usuario
         * @param pass
         * @throws Exception 
         */
        public static void insertar(String usuario, String pass) throws Exception{
        
       
            GenericoBD.abrirConexion();   
            
            String plantilla;

            plantilla = "INSERT INTO Login VALUES (?, ?)";
            
            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);
            
            ps.setString(1, usuario);
            ps.setString(2, pass);

            ps.executeUpdate();
            
            
            cerrarConexion();
        
        
            
        }
        
        /**
          * Borra un usuario de Login de la base de datos
          * @param usu
          * @throws Exception 
          */
        public static void borrar(String usu)throws Exception{
        
            abrirConexion();  
            String plantilla;

            plantilla = "DELETE FROM Login WHERE usuario = ?";

            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);
            ps.setString(1, usu);
             
            ps.executeUpdate();
            
            
            cerrarConexion();
            
        }
        
        /**
         * Actualiza la contrase de un usuario de Login de la base de datos
         * @param pass
         * @param usu
         * @throws Exception 
         */
        public static void actualizarPass(String pass, String usu) throws Exception{
            abrirConexion();   
            String plantilla;

            plantilla = "UPDATE Login SET contrasena = ? WHERE usuario = ? ";

            PreparedStatement ps = GenericoBD.getCon().prepareStatement(plantilla);

            ps.setString(1, pass);
            
            ps.setString(2, usu);
            ps.executeUpdate();
            
          
            cerrarConexion();
            
            
        }
}
