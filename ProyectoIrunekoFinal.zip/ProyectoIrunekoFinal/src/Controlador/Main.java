package Controlador;

import Vista.*;
import Modelo.*;
import java.sql.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class Main {

    
    private static VentanaLogin vl;
    private static VentanaPrincipal vp;
    
    private static DialogTrabajador dt;
    private static DialogUsuario du;
    private static VentanaNuevoTrabajador vnt; 
    private static VentanaModificarTrabajador vmt;
    
    private static DialogCentro dc;
    private static VentanaNuevoCentro vnc;
    private static VentanaModificarCentro vmc;
    
    private static VentanaNuevoParte vnp;
    private static VentanaBuscarParte vbp;
    
    private static Trabajador t;
    private static Trabajador logged;
    private static Centro c;   
    private static Centro clogged;
    private static Login l;
    private static Login l2;
    private static Parte p;
    private static Viaje v;
    
    
    private static String tipo;
    private static String tipologged;
    private static String usuario;
    
    
    private static int x;
    private static int y;
    
    public static void main(String[] args) {
        
        l = new Login();
        t = new Trabajador();
        p = new Parte();
        logged = new Trabajador(); 
        mostrarLogin();
        
        
    }
    
    /**
     * Llama a la funcion que guarda el usuario y la contraseña
     * @param usuario
     * @param pass 
     */
    public static void insertarLogin(String usuario, String pass){
        try {
            LoginBD.insertar(usuario, pass);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ha habido un error insertando el Login: " + e.getMessage());
        }
    }
    
    /**
     * Llama a la funcion que cambia la contraseña anterior por la que se ha introducido como nueva
     * @param pass
     * @param usuario 
     */
    public static void actualizarPass(String pass, String usuario){
        try {
            LoginBD.actualizarPass(pass, usuario);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ha habido un error cambiando el usuario/contraseña: " + e.getMessage());
        }
    }
    
    /**
     * Llama a la funcion que elimina el usuario que se pasa como parametro
     * @param usuario 
     */
    public static void borrarUsuario(String usuario){
        try {
            LoginBD.borrar(usuario);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ha habido un error borrando el usuario: " + e.getMessage());
        }
    }
    
    /**
     * Llama a la funcion que cambia el usuario anterior por el que se ha introducido como nuevo
     * @param usuario 
     * @param dni
     */
    
    public static void actualizarUsuario(String usuario, String dni){
        try {
            TrabajadorBD.actualizarUsuario(usuario, dni);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ha habido un error actualizando el usuario: " + e.getMessage());
        }
    }
    
    /**
     * Llama a la funcion que elimina el centro del id que se pasa como parametro
     * @param id 
     */
    public static void borrarCentro(String id){
        try {
            CentroBD.borrar(id);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ha habido un error borrando el centro: " + e.getMessage());
        }
    }
    
    /**
     * Llama a la funcion que elimina el trabajador del dni que se pasa como parametro
     * @param dni 
     */
    public static void borrarTrabajador(String dni){
        try {
            TrabajadorBD.borrar(dni);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ha habido un error borrando el trabajador: " + e.getMessage());
        }
    }
    
    /**
     * Llama a la funcion que comprueba si el usuario existe en la base de datos
     * @param usuario
     * @param password
     * @return 
     */
    public static Login loginUsuario(String usuario, String password){
        try {
            l = LoginBD.loginUsuario(usuario, password);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ha habido un error buscando el usuario: " + e.getMessage());
        }
        return l;
    }
    
    /**
     * Llama a la funcion que introduce todos los cambios realizados respecto al centro en la base de datos
     * @param nombre
     * @param telefono
     * @param cp
     * @param provincia
     * @param ciudad
     * @param calle
     * @param numero
     * @param centro 
     */
    public static void actualizarCentro(String nombre, String telefono, String cp, String provincia, String ciudad, String calle, String numero, String centro){
        try{
            CentroBD.actualizar(nombre, telefono, cp, provincia, ciudad, calle, numero, centro);
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Ha habido un error actualizando el centro: " + e.getMessage());
        }
    }
    
    /**
     * Llama a la funcion que introduce todos los cambios realizados respecto al trabajador en la base de datos
     * @param nombre
     * @param ape1
     * @param ape2
     * @param calle
     * @param numero
     * @param piso
     * @param mano
     * @param tlfemp
     * @param tlfper
     * @param fechanac
     * @param sal
     * @param tipo
     * @param centro
     * @param dni 
     */
    public static void actualizarTrabajador(String nombre, String ape1, String ape2, String calle, String numero, String piso, String mano, String tlfemp, String tlfper, Calendar fechanac, float sal, String tipo, String centro, String dni){
        try{
            TrabajadorBD.actualizar(nombre, ape1, ape2, calle, numero, piso, mano, tlfemp, tlfper, fechanac, sal, tipo, centro, dni);
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Ha habido un error actualizando el centro: " + e.getMessage());
        }
    }
    
    /**
     * Llama a la funcion que segun el id de centro que se le pase como parametro comprueba si existe en la base de datos o no
     * @param id
     * @return 
     */
    public static Centro buscarCentroID(String id){
        try {
            c = CentroBD.buscarCentroID(id);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ha habido un error buscando centros: " + e.getMessage());
        }
        return c;
    }
    
    /**
     * Llama a la funcion que inserta los datos del nuevo centro en la base de datos
     * @param id
     * @param nom
     * @param fijo
     * @param codp
     * @param prov
     * @param ciu
     * @param cal
     * @param num 
     */
    public static void insertarCentro(String id, String nom, String fijo, String codp, String prov, String ciu, String cal, String num){
        try {
            CentroBD.insertar(id, nom, fijo, codp, prov, ciu, cal, num);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ha habido un error insertando el centro: " + e.getMessage());
        }
    }
    
    /**
     * Llama a la funcion que inserta los datos del nuevo parte en la base de datos
     * @param id
     * @param fecha
     * @param kminicio
     * @param kmfin
     * @param gasoil
     * @param auto
     * @param dieta
     * @param otros
     * @param incidencia
     * @param dni 
     */
    public static void insertarParte(String id, Calendar fecha, float kminicio, float kmfin, float gasoil, float auto, float dieta, float otros, String incidencia, String dni){
        try {
            ParteBD.insertar(fecha, kminicio, kmfin, gasoil, auto, dieta, otros, incidencia, dni);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ha habido un error insertando el parte: " + e.getMessage());
        }
    }
    
    /**
     * Llama a la funcion que inserta los datos del nuevo trabajador en la base de datos
     * @param dni
     * @param nom
     * @param ape1
     * @param ape2
     * @param calle
     * @param num
     * @param piso
     * @param mano
     * @param emp
     * @param per
     * @param fech
     * @param sal
     * @param tipo
     * @param centro
     * @param usuario 
     */
    public static void insertarTrabajador(String dni, String nom, String ape1, String ape2, String calle, String num, String piso, String mano, String emp, String per,Calendar fech, Float sal, String tipo, String centro, String usuario){
        try {
            TrabajadorBD.insertar(dni, nom, ape1, ape2, calle, num, piso, mano, emp, per, fech, sal, tipo, centro, usuario);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ha habido un error insertando el parte: " + e.getMessage());
        }
    }
    
    
    /**
     * Llama a la funcion que busca un trabajador por su DNI
     * @param dni
     * @return 
     */
    public static Trabajador buscarTrabajadorDNI(String dni){
        try {
            t = TrabajadorBD.buscarDni(dni);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ha habido un error buscando el trabajador: " + e.getMessage());
        }
        return t;
    }
    
    /**
     * Llama a la funcion que busca un parte por si ID de parte
     * @param id
     * @return 
     */
    public static Parte buscarParteID(String id){
        try{
            p = ParteBD.buscarID(id);
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Ha habido un error buscando el parte: " + e.getMessage());
        }
        return p;
    }
    
    /**
     * Llama a la funcion que actualiza los valores del parte en concreto que tu quieras
     * @param kminicio
     * @param kmfin
     * @param gasoil
     * @param auto
     * @param dieta
     * @param otros
     * @param incidencia
     * @param id 
     */
    public static void actualizarParte(float kminicio, float kmfin, float gasoil, float auto, float dieta, float otros, String incidencia, String id){
        try{
            ParteBD.actualizar( kminicio, kmfin, gasoil, auto, dieta, otros, incidencia, id);
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Ha habido un error modificando el parte: " + e.getMessage());
        }
        
    }
    
    /**
     * Llama a la funcion que borra el parte que tu pases por parametro
     * @param id 
     */
    public static void borrarParte(String id){
        try{
            ParteBD.borrar(id);
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Ha habido un error borrando el parte: " + e.getMessage());
        }
    }
    
    /**
     * Llama a la funcion que actualiza el estado de un parte como cerrado.
     * @param id 
     */
    public static void cerrarParte(String id){
        try{
            ParteBD.cerrarParte(id);
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Ha habido un error cerrando el parte: " + e.getMessage());
        }
    }
    
    /**
     * Llama a la funcion que permite a un administrado validar un parte
     * @param id 
     */
    public static void validarParte(String id){
        try{
            ParteBD.validarParte(id);
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Ha habido un error validando el parte: " + e.getMessage());
        }
    }
    
    /**
     * Llama a la funcion que busca los datos del viaje que pertenezcan al ID que pases por parametro
     * @param albaran
     * @return 
     */
    public static Viaje buscarViajeID(String albaran){
        try{
            v = ViajeBD.buscarViajeID(albaran);
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Ha habido un error buscando el viaje: " + e.getMessage());
        }
        return v;
    }
    
    /**
     * Llama a la funcion que borra el viaje introducido
     * @param albaran 
     */
    public static void borrarViaje(String albaran){
        try{
            ViajeBD.borrar(albaran);
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Ha habido un error borrando el viaje: " + e.getMessage());
        }
    }
    
    /**
     * Llama a la funcion que inserta el viaje con los valores introducidos por parametro
     * @param horasal
     * @param horalle
     * @param idparte
     * @param vehiculo 
     */
    public static void insertarViaje(String horasal, String horalle, String idparte, String vehiculo){
        try{
            ViajeBD.insertar(horasal, horalle, idparte, vehiculo);
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Ha habido un error insertando viaje: " + e.getMessage());
        }
    }
    
    /**
     * Llama a la funcion que actualiza los valores del viaje por los introducidos por parametro
     * @param albaran
     * @param horasal
     * @param horalle
     * @param vehiculo 
     */
    public static void actualizarViaje(String albaran, String horasal, String horalle,  String vehiculo){
        try{
            ViajeBD.actualizar(albaran, horasal, horalle,  vehiculo);
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Ha habido un error modificando el viaje: " + e.getMessage());
        }
    }
    
    
    // ARRAYLIST Y DATOS //
    
    /**
     * Retorna un ArrayList lleno de todos los centros 
     * @return
     * @throws Exception 
     */
    public static ArrayList<Centro> Centros() throws Exception{
        return CentroBD.buscarCentros();
 
    }
    
    /**
     * Se obtiene el nombre del centro a partir del id que se pasa como parametro
     * @param idCentro
     * @return
     * @throws Exception 
     */
    public static String nombreCentro(String idCentro) throws Exception{
        c = CentroBD.buscarCentroID(idCentro);
        return c.getNombre();
    }
    
    /**
     * Se obtienen los datos del trabajador a partir dni que se pasa como para metro
     * @param dni
     * @return
     * @throws Exception 
     */
    public static Trabajador datosTrabajador(String dni) throws Exception{
        t = TrabajadorBD.buscarDni(dni);
        return t;
    }
    
    
    
// MOSTRAR VENTANAS //
    
    /**
     * Muestra la ventana de login
     */
    public static void mostrarLogin(){
        vl = new VentanaLogin();
        vl.setVisible(true);
    }
    
    /**
     * Muestra la ventana principal del programa
     */
    public static void mostrarVentanaPrincipal(){
        vp = new VentanaPrincipal();
        vp.setVisible(true);
    }
    
    /**
     * Muestra la ventana principal
     */
    public static void visiblefalsePrincipal(){
        vp.setVisible(false);        
    }
    
    /**
     * Muestra que accion queremos hacer con los trabajadores
     */
    public static void mostrarDialogTrabajador(){
        dt = new DialogTrabajador(vp, true);
        dt.setVisible(true);
    }
    
    /**
     * Muestra la ventana que modifica el usuario y la contraseña del trabajador que estamos modificando
     */
    public static void mostrarDialogUsuario(){
        du = new DialogUsuario(vmt, true);
        du.setVisible(true);
    }
    
    /**
     * Muestra la ventana que permite introducir un nuevo trabajador
     */
    public static void mostrarVentanaNuevoTrabajador(){
        vnt = new VentanaNuevoTrabajador();
        vnt.setVisible(true);
    }
    
    /**
     * Muestra la ventana que permite modificar o borrar un trabajador
     */
    public static void mostrarVentanaModificarTrabajador(){
        vmt = new VentanaModificarTrabajador();
        vmt.setVisible(true);
    }
    
    /**
     * Muestra la ventana que permite elegir que hacer con los centros
     */
    public static void mostrarDialogCentro(){
        dc = new DialogCentro(vp, true);
        dc.setVisible(true);        
    }
    
    /**
     * Muestra la ventana que permite insertar un nuevo centro
     */
    public static void mostrarVentanaNuevoCentro(){
        vnc = new VentanaNuevoCentro();
        vnc.setVisible(true);
    }
   
    /**
     * Muestra la ventana que permite modificar o borrar un centro
     */
    public static void mostrarVentanaModificarCentro(){
        vmc = new VentanaModificarCentro();
        vmc.setVisible(true);
    }
    
    /**
     * Muestra la ventana que nos permite introducir un parte nuevo
     */
    public static void mostrarVentanaNuevoParte(){
        vnp = new VentanaNuevoParte();
        vnp.setVisible(true);
    }
    
    /**
     * Muestra la ventana que nos permite buscar y actuar sobre un parte
     */
    public static void mostrarVentanaBuscarParte(){
        vbp = new VentanaBuscarParte();
        vbp.setVisible(true);
    }
    
    
    // RECOGIDA DE DATOS //
    
    /**
     * Convierte la contraseña en un String
     * @param pass 
     */
    public static String obtenerContrasena(char[] pass){
        String contrasena = "";
        for(int x =0; x < pass.length ; x++){
            contrasena += pass[x]; 
        }
        return contrasena;
    }
    
    /**
     * Nos recoge en un objeto al trabajador que somos cuando logeamos
     * @param usuario
     * @throws Exception 
     */
    public static void obtenerTrabajadorLogin(String usuario)throws Exception{
        
        logged = TrabajadorBD.buscarporUsuario(usuario);
        
    }
    
    /**
     * Permite guardar en un objeto un trabajador con el que vamos a operar
     * @param tr
     * @throws Exception 
     */
    public static void obtenerTrabajador(Trabajador tr)throws Exception{
        
        t = TrabajadorBD.buscarDni(tr.getDni());
        
    }
    
    /**
     * Guarda un centro en un objeto para poder actuar sobre el
     * @param id
     * @throws Exception 
     */
    public static void guardarCentro(String id)throws Exception{
        
        c = CentroBD.buscarCentroID(id);
        
    }  
    
    /**
     * Guarda el centro de trabajo en el que trabaja la persona que ha iniciado sesion
     * @param id
     * @throws Exception 
     */
    
    public static void guardarCentroLogged(String id)throws Exception{
        clogged = CentroBD.buscarCentroID(id);
        
    }
    
    // GETTER & SETTER // 

    /**
     * Retorna los valores de Centro
     * @return 
     */
    public static Centro getC() {
        return c;
    }

    /**
     * Retorna los valores de Trabajador que estamos editando
     * @return 
     */
    public static Trabajador getT() {
        return t;
    }

    /**
     * Retorna la fecha
     * @return 
     */
    public static Calendar getFecha(){
        Calendar cal =  Calendar.getInstance();
        cal.setTime(t.getFecha_nac());
        return cal;
    }

    /**
     * Retorna el tipo del Trabajador que estamos editando
     * @return 
     */
    public static String getTipo() {
        return tipo;
    }

    /**
     * Guarda el tipo del Trabajador que estamos editando
     * @param tipo 
     */
    public static void setTipo(String tipo) {
        Main.tipo = tipo;
    }


    /**
     * Retorna el Usuario del Trabajador que estamos editando
     * @return 
     */
    public static String getUsuario() {
        return usuario;
    }

    /**
     * Guarda el Usuario del Trabajador que estamos editando
     * @param usuario 
     */
    public static void setUsuario(String usuario) {
        Main.usuario = usuario;
    }

    /**
     * Retorna el Trabajador en el que hemos iniciado sesion
     * @return 
     */
    public static Trabajador getLogged() {
        return logged;
    }

    /**
     * Retorna el tipo del Trabajador en el que hemos iniciado sesion
     * @return 
     */
    public static String getTipologged() {
        return tipologged;
    }

    /**
     * Guarda el tipo del Trabajador en el que iniciamos sesion
     * @param tipologged 
     */
    public static void setTipologged(String tipologged) {
        Main.tipologged = tipologged;
    }

    /**
     * Retorna el Login de la persona que estamos introduciendo o editando
     * @return 
     */
    public static Login getL2() {
        return l2;
    }

    /**
     * Guarda el Login de la persona que estamos introduciendo o editando
     * @param l2 
     */
    public static void setL2(Login l2) {
        Main.l2 = l2;
    }

    /**
     * Retorna los datos del Centro donde trabaja el Trabajador que ha iniciado sesión
     * @return 
     */
    public static Centro getClogged() {
        return clogged;
    }

    /**
     * Retorna el Parte guardado
     * @return 
     */
    public static Parte getP() {
        return p;
    }

    
    
    

    
 
}
