/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import Controlador.Main;
import Modelo.ParteBD;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import Modelo.*;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JTextField;

/**
 *
 * @author 1gprog04
 */
public class VentanaBuscarParte extends javax.swing.JFrame {

    /**
     * Creates new form VentanaParte
     */
    public VentanaBuscarParte() {
        initComponents();
        llenarComboCentro();
        desactivarCampos();
        
        setLocationRelativeTo(null);
        
        desactivarCamposViaje(Albaran1, horaS1, horaL1, comboVehiculo1, bAceptar1);
        desactivarCamposViaje(Albaran2, horaS2, horaL2, comboVehiculo2, bAceptar2);
        desactivarCamposViaje(Albaran3, horaS3, horaL3, comboVehiculo3, bAceptar3);
        desactivarCamposViaje(Albaran4, horaS4, horaL4, comboVehiculo4, bAceptar4);
        desactivarCamposViaje(Albaran5, horaS5, horaL5, comboVehiculo5, bAceptar5);
        vaciarCamposViaje(Albaran1, horaS1, horaL1, comboVehiculo1);
        vaciarCamposViaje(Albaran2, horaS2, horaL2, comboVehiculo2);
        vaciarCamposViaje(Albaran3, horaS3, horaL3, comboVehiculo3);
        vaciarCamposViaje(Albaran4, horaS4, horaL4, comboVehiculo4);
        vaciarCamposViaje(Albaran5, horaS5, horaL5, comboVehiculo5);
        
        radioTodos.setSelected(true);
        
        if("A".equals(Controlador.Main.getTipologged())){
            comboDNI.setEnabled(true);
            bCerrarValidar.setText("Validar parte");
            bNuevo.setEnabled(false);

            
        }
        
        if("L".equals(Controlador.Main.getTipologged())){
            comboCentro.setEnabled(false);
            comboDNI.setEnabled(false);
            comboCentro.setSelectedItem(Controlador.Main.getClogged().getId_centro());
            comboDNI.setSelectedItem(Controlador.Main.getLogged().getDni());
            
        }
        
        
        if("Cerrado".equals(Controlador.Main.getP().getEstado())){
            bCerrarValidar.setEnabled(false);
        }
        
    }
    /**
     * Llena campos
     */
    public void llenarCampos(){
        if("Abierto".equals(Controlador.Main.getP().getEstado())){
            bCerrarValidar.setEnabled(true);
        }
        tfkmi.setText(String.valueOf(Controlador.Main.getP().getKmini()));
        tfkmf.setText(String.valueOf(Controlador.Main.getP().getKmfin()));
        tfkmt.setText(String.valueOf(Controlador.Main.getP().getKmfin() - Controlador.Main.getP().getKmini()));
        tfGasoil.setText(String.valueOf(Controlador.Main.getP().getGasoil()));
        tfAutopista.setText(String.valueOf(Controlador.Main.getP().getAutopista()));
        tfDieta.setText(String.valueOf(Controlador.Main.getP().getDieta()));
        tfOtros.setText(String.valueOf(Controlador.Main.getP().getOtros_gastos()));
        tArea1.setText(Controlador.Main.getP().getIncidencias());
        labelEstado.setText(Controlador.Main.getP().getEstado());
        labelValidado.setText(Controlador.Main.getP().getValidado());
    }
    
    /**
     * Desactiva campos
     */
    public void desactivarCampos(){
        comboDNI.setEditable(false);
        tfNombre.setEditable(false);
        tfApellidos.setEditable(false);
        radioTodos.setEnabled(false);
        radioFechas.setEnabled(false);
        dateChooserCombo1.setEnabled(false);
        dateChooserCombo2.setEnabled(false);
        
        comboIDParte.setEnabled(false);
        tfkmi.setEnabled(false);
        tfkmf.setEnabled(false);
        tfkmt.setEnabled(false);
        tfGasoil.setEnabled(false);
        tfDieta.setEnabled(false);
        tfAutopista.setEnabled(false);
        tfOtros.setEnabled(false);
        tArea1.setEnabled(false);
        bCerrarValidar.setEnabled(false);
        
        bAceptar.setEnabled(false);
        radioEditar.setEnabled(false);
        radioBorrar.setEnabled(false);
        
        bVisualizar.setEnabled(false);
        
        bEdit1.setEnabled(false);
        bBorrar1.setEnabled(false);
        bEdit2.setEnabled(false);
        bBorrar2.setEnabled(false);
        bEdit3.setEnabled(false);
        bBorrar3.setEnabled(false);
        bEdit4.setEnabled(false);
        bBorrar4.setEnabled(false);
        bEdit5.setEnabled(false);
        bBorrar5.setEnabled(false);
    }
    
    /**
     * Desactiva solo los campos de Parte
     */
    public void desactivarCamposParte(){
        comboIDParte.setEnabled(false);
        tfkmi.setEnabled(false);
        tfkmf.setEnabled(false);
        tfkmt.setEnabled(false);
        tfGasoil.setEnabled(false);
        tfDieta.setEnabled(false);
        tfAutopista.setEnabled(false);
        tfOtros.setEnabled(false);
        tArea1.setEnabled(false);
        bEdit1.setEnabled(false);
        bBorrar1.setEnabled(false);
        bEdit2.setEnabled(false);
        bBorrar2.setEnabled(false);
        bEdit3.setEnabled(false);
        bBorrar3.setEnabled(false);
        bEdit4.setEnabled(false);
        bBorrar4.setEnabled(false);
        bEdit5.setEnabled(false);
        bBorrar5.setEnabled(false);
    }
    
    /**
     * Vacia los campos que introduzcas por parametro
     * @param albaran
     * @param horas
     * @param horal
     * @param vehiculo 
     */
    public void vaciarCamposViaje(JTextField albaran, JTextField horas, JTextField horal, JComboBox vehiculo){
            albaran.setText("");
            horas.setText("");
            horal.setText("");
            vehiculo.setSelectedIndex(-1);
    }
    
    /**
     * Activa los campos de los Partes
     */
    public void activarCamposParte(){
        tfkmi.setEnabled(true);
        tfkmf.setEnabled(true);
        tfGasoil.setEnabled(true);
        tfDieta.setEnabled(true);
        tfAutopista.setEnabled(true);
        tfOtros.setEnabled(true);
        tArea1.setEnabled(true);
        bSalir.setEnabled(true);
    }
    
    /**
     * Desactiva los campos de viaje que pases por parametro
     * @param albaran
     * @param horas
     * @param horal
     * @param vehiculo
     * @param aceptar 
     */
    public void desactivarCamposViaje(JTextField albaran, JTextField horas, JTextField horal, JComboBox vehiculo, JButton aceptar){
        albaran.setEditable(false);
        horas.setEditable(false);
        horal.setEditable(false);
        vehiculo.setEnabled(false);
        aceptar.setEnabled(false);
    }
    
    /**
     * Activa los campos de viaje que pases por parametro
     * @param horas
     * @param horal
     * @param vehiculo
     * @param aceptar 
     */
    public void activarCamposViaje(JTextField horas, JTextField horal, JComboBox vehiculo, JButton aceptar){
        horas.setEditable(true);
        horal.setEditable(true);
        vehiculo.setEnabled(true);
        aceptar.setEnabled(true);
    }
    
    /**
     * Llena el combo de centros
     */
    public void llenarComboCentro(){
        try
        {
            ArrayList<Centro> centros = Controlador.Main.Centros();
            for(int x = 0; x < centros.size(); x++){
            comboCentro.insertItemAt(centros.get(x).getId_centro(), x);
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(this, "Ha ocurrido el siguiente error consultando centros " + e.getMessage());
        }
        
    }
    
    /**
     * Llena el combo de DNIs
     */
    public void llenarComboDNI(){
       try
        {
            Centro c = CentroBD.buscarCentroID(comboCentro.getSelectedItem().toString());
            ArrayList<Trabajador> trabajadores = c.getTrabajadoresLogi();
            for(int x = 0; x < trabajadores.size(); x++){
                comboDNI.insertItemAt(trabajadores.get(x).getDni(), x);
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(this, "Ha ocurrido el siguiente error consultando DNI " + e.getMessage());
        }
        
    }
    
   
    /**
     * Llena el combo de todos los IDs de partes
     */
    public void llenarComboIDParte(){
       try
        {
            String IDs = "";
            
            Trabajador t = TrabajadorBD.buscarDni(comboDNI.getSelectedItem().toString());
            
            ArrayList<Parte> partes = t.getParteDNI();
            
            for(int x = 0; x < partes.size(); x++){
                comboIDParte.insertItemAt(partes.get(x).getIdparte(), x); 
            }
            
            ArrayList<Parte> abiertos = t.getParteDNIAbiertos();
            for(int y = 0; y < abiertos.size(); y++){
                IDs += "\n" + abiertos.get(y).getIdparte();
            }
            
            if(Controlador.Main.getLogged().getDni().equals(comboDNI.getSelectedItem().toString())){
                JOptionPane.showMessageDialog(this, "Tienes abiertos los siguientes partes: " + IDs);
            }
            else
            {
                JOptionPane.showMessageDialog(this, "Este usuario tiene abiertos los siguientes partes: " + IDs);
            }
            
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(this, "Ha ocurrido el siguiente error consultando partes " + e.getMessage());
        }
        
    }
    
    /**
     * Llena el combo de los IDs de partes entre ciertas fechas
     */
    public void llenarComboIDParteFechas(){
       try
        {
            Trabajador t = TrabajadorBD.buscarDni(comboDNI.getSelectedItem().toString());
            ArrayList<Parte> partes = t.getParteDNIFechas(dateChooserCombo1.getSelectedDate(), dateChooserCombo2.getSelectedDate());
            for(int x = 0; x < partes.size(); x++){
            comboIDParte.insertItemAt(partes.get(x).getIdparte(), x);
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(this, "Ha ocurrido el siguiente error consultando partes " + e.getMessage());
        }
        
    }
    
    /**
     * Llena todos los campos de viajes
     * @param id 
     */
    public void llenarViajes(String id){
        try{
            Parte p = Controlador.Main.buscarParteID(id);
            ArrayList<Viaje> viajes = p.getViajes();
            ArrayList<JTextField> albaranes = new ArrayList();
                albaranes.add(Albaran1);
                albaranes.add(Albaran2);
                albaranes.add(Albaran3);
                albaranes.add(Albaran4);
                albaranes.add(Albaran5);
            
            ArrayList<JTextField> horasalidas = new ArrayList();
                horasalidas.add(horaS1);
                horasalidas.add(horaS2);
                horasalidas.add(horaS3);
                horasalidas.add(horaS4);
                horasalidas.add(horaS5);
                
            ArrayList<JTextField> horallegadas = new ArrayList();
                horallegadas.add(horaL1);
                horallegadas.add(horaL2);
                horallegadas.add(horaL3);
                horallegadas.add(horaL4);
                horallegadas.add(horaL5);
                
            ArrayList<JComboBox> vehiculos = new ArrayList();
                vehiculos.add(comboVehiculo1);
                vehiculos.add(comboVehiculo2);
                vehiculos.add(comboVehiculo3);
                vehiculos.add(comboVehiculo4);
                vehiculos.add(comboVehiculo5);
            
            for(int x = 0; x < viajes.size(); x++){
                albaranes.get(x).setText(viajes.get(x).getAlbaran());
                horasalidas.get(x).setText(viajes.get(x).getHorasalida());
                horallegadas.get(x).setText(viajes.get(x).getHorallegada());
                vehiculos.get(x).setSelectedItem(viajes.get(x).getVehiculo());
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(this, "Ha ocurrido el siguiente error buscando viajes " + e.getMessage());
        }
    }
    
    /**
     * Vacia los campos de Parte
     */
    public void vaciarCamposParte(){
            tfkmi.setText("");
            tfkmf.setText("");
            tfkmt.setText("");
            tfGasoil.setText("");
            tfDieta.setText("");
            tfAutopista.setText("");
            tfOtros.setText("");
            tArea1.setText("");
    }
        

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        grupo1 = new javax.swing.ButtonGroup();
        grupo2 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        comboCentro = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        comboDNI = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        tfNombre = new javax.swing.JTextField();
        tfApellidos = new javax.swing.JTextField();
        radioTodos = new javax.swing.JRadioButton();
        radioFechas = new javax.swing.JRadioButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        dateChooserCombo1 = new datechooser.beans.DateChooserCombo();
        dateChooserCombo2 = new datechooser.beans.DateChooserCombo();
        bVisualizar = new javax.swing.JButton();
        bNuevo = new javax.swing.JButton();
        jPanel12 = new javax.swing.JPanel();
        bCerrarValidar = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jLabel25 = new javax.swing.JLabel();
        Albaran4 = new javax.swing.JTextField();
        jLabel30 = new javax.swing.JLabel();
        comboVehiculo4 = new javax.swing.JComboBox<>();
        jLabel35 = new javax.swing.JLabel();
        horaS4 = new javax.swing.JTextField();
        jLabel45 = new javax.swing.JLabel();
        horaL4 = new javax.swing.JTextField();
        bAceptar4 = new javax.swing.JButton();
        bEdit4 = new javax.swing.JButton();
        bBorrar4 = new javax.swing.JButton();
        jPanel10 = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        Albaran3 = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        comboVehiculo3 = new javax.swing.JComboBox<>();
        jLabel34 = new javax.swing.JLabel();
        horaS3 = new javax.swing.JTextField();
        jLabel44 = new javax.swing.JLabel();
        horaL3 = new javax.swing.JTextField();
        bAceptar3 = new javax.swing.JButton();
        bEdit3 = new javax.swing.JButton();
        bBorrar3 = new javax.swing.JButton();
        jPanel9 = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        Albaran1 = new javax.swing.JTextField();
        jLabel27 = new javax.swing.JLabel();
        comboVehiculo1 = new javax.swing.JComboBox<>();
        jLabel32 = new javax.swing.JLabel();
        horaS1 = new javax.swing.JTextField();
        jLabel38 = new javax.swing.JLabel();
        horaL1 = new javax.swing.JTextField();
        bAceptar1 = new javax.swing.JButton();
        bEdit1 = new javax.swing.JButton();
        bBorrar1 = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jLabel26 = new javax.swing.JLabel();
        Albaran5 = new javax.swing.JTextField();
        jLabel31 = new javax.swing.JLabel();
        comboVehiculo5 = new javax.swing.JComboBox<>();
        jLabel36 = new javax.swing.JLabel();
        horaS5 = new javax.swing.JTextField();
        jLabel46 = new javax.swing.JLabel();
        horaL5 = new javax.swing.JTextField();
        bAceptar5 = new javax.swing.JButton();
        bEdit5 = new javax.swing.JButton();
        bBorrar5 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        tfGasoil = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        tfAutopista = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        tfDieta = new javax.swing.JTextField();
        tfOtros = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        radioEditar = new javax.swing.JRadioButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tArea1 = new javax.swing.JTextArea();
        jLabel20 = new javax.swing.JLabel();
        radioBorrar = new javax.swing.JRadioButton();
        labelEstado = new javax.swing.JLabel();
        comboIDParte = new javax.swing.JComboBox<>();
        jPanel4 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        tfkmi = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        tfkmf = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        tfkmt = new javax.swing.JTextField();
        jLabel37 = new javax.swing.JLabel();
        labelValidado = new javax.swing.JLabel();
        bAceptar = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        Albaran2 = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        comboVehiculo2 = new javax.swing.JComboBox<>();
        jLabel33 = new javax.swing.JLabel();
        horaS2 = new javax.swing.JTextField();
        jLabel39 = new javax.swing.JLabel();
        horaL2 = new javax.swing.JTextField();
        bAceptar2 = new javax.swing.JButton();
        bEdit2 = new javax.swing.JButton();
        bBorrar2 = new javax.swing.JButton();
        bSalir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(204, 204, 255));

        jPanel1.setBackground(new java.awt.Color(255, 102, 102));

        jLabel7.setFont(new java.awt.Font("Verdana", 1, 24)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("Busqueda de Partes");

        jPanel3.setBackground(new java.awt.Color(255, 240, 240));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel4.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel4.setText("Centro:");

        comboCentro.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                comboCentroItemStateChanged(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel1.setText("Operario:");

        comboDNI.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                comboDNIItemStateChanged(evt);
            }
        });
        comboDNI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboDNIActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel5.setText("Nombre:");

        jLabel6.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel6.setText("Apellidos:");

        grupo1.add(radioTodos);
        radioTodos.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        radioTodos.setText("Todos");
        radioTodos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radioTodosActionPerformed(evt);
            }
        });

        grupo1.add(radioFechas);
        radioFechas.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        radioFechas.setText("Entre fechas");
        radioFechas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radioFechasActionPerformed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(255, 240, 240));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 51, 51)), "Entre fechas", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 0, 11))); // NOI18N

        jLabel2.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel2.setText("Inicio");

        jLabel3.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel3.setText("Fin");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(dateChooserCombo2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(dateChooserCombo1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(60, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dateChooserCombo1, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dateChooserCombo2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27))
        );

        bVisualizar.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        bVisualizar.setText("Visualizar");
        bVisualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bVisualizarActionPerformed(evt);
            }
        });

        bNuevo.setFont(new java.awt.Font("Verdana", 0, 11)); // NOI18N
        bNuevo.setText("Parte nuevo");
        bNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bNuevoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(100, 100, 100)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel1)
                            .addComponent(jLabel5))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(tfNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(comboCentro, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(comboDNI, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(185, 185, 185)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(radioTodos)
                            .addComponent(radioFechas)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfApellidos, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(102, 102, 102)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(bNuevo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(bVisualizar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(130, 130, 130))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(61, 61, 61)
                        .addComponent(bNuevo)
                        .addGap(18, 18, 18)
                        .addComponent(bVisualizar))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel4)
                                    .addComponent(comboCentro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(13, 13, 13)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel1)
                                    .addComponent(comboDNI, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(radioTodos))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel5)
                                    .addComponent(tfNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(radioFechas))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel6)
                                    .addComponent(tfApellidos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addContainerGap(37, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(554, 554, 554)
                .addComponent(jLabel7)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel7)
                .addGap(20, 20, 20)
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel12.setBackground(new java.awt.Color(255, 240, 240));

        bCerrarValidar.setText("Cerrar Parte");
        bCerrarValidar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCerrarValidarActionPerformed(evt);
            }
        });

        jPanel6.setBackground(new java.awt.Color(255, 240, 240));
        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Viaje 4", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Lucida Grande", 0, 14))); // NOI18N

        jLabel25.setText("Albarán:");

        Albaran4.setText(" ");

        jLabel30.setText("Vehiculo:");

        comboVehiculo4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Transporter", "Traffic", "Berlingo", "C15" }));
        comboVehiculo4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboVehiculo4ActionPerformed(evt);
            }
        });

        jLabel35.setText("Hora Salida:");

        horaS4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                horaS4ActionPerformed(evt);
            }
        });

        jLabel45.setText("Hora Llegada:");

        bAceptar4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/tick.png"))); // NOI18N
        bAceptar4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAceptar4ActionPerformed(evt);
            }
        });

        bEdit4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/edit (1).png"))); // NOI18N
        bEdit4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bEdit4ActionPerformed(evt);
            }
        });

        bBorrar4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/editdelete.png"))); // NOI18N
        bBorrar4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bBorrar4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel25)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Albaran4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel35)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(horaS4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(jLabel45)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(horaL4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel30)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(comboVehiculo4, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(bAceptar4, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(bEdit4, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(bBorrar4, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel25)
                            .addComponent(Albaran4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel30)
                            .addComponent(comboVehiculo4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel35)
                            .addComponent(horaS4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel45)
                            .addComponent(horaL4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(bEdit4, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(bAceptar4, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(bBorrar4, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(28, Short.MAX_VALUE))
        );

        jPanel10.setBackground(new java.awt.Color(255, 240, 240));
        jPanel10.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Viaje 3", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Lucida Grande", 0, 14))); // NOI18N

        jPanel11.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Viaje 1", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Lucida Grande", 0, 14))); // NOI18N

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 578, Short.MAX_VALUE)
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jLabel24.setText("Albarán:");

        Albaran3.setText(" ");

        jLabel29.setText("Vehiculo:");

        comboVehiculo3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Transporter", "Traffic", "Berlingo", "C15" }));
        comboVehiculo3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboVehiculo3ActionPerformed(evt);
            }
        });

        jLabel34.setText("Hora Salida:");

        jLabel44.setText("Hora Llegada:");

        bAceptar3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/tick.png"))); // NOI18N
        bAceptar3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAceptar3ActionPerformed(evt);
            }
        });

        bEdit3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/edit (1).png"))); // NOI18N
        bEdit3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bEdit3ActionPerformed(evt);
            }
        });

        bBorrar3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/editdelete.png"))); // NOI18N
        bBorrar3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bBorrar3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel24)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Albaran3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel34)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(horaS3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(jLabel44)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(horaL3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel29)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(comboVehiculo3, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(bAceptar3, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(bEdit3, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(bBorrar3, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel10Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(40, Short.MAX_VALUE)))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(horaL3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel29)
                                .addComponent(comboVehiculo3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel24)
                                .addComponent(Albaran3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel34)
                                .addComponent(horaS3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel44))))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(bEdit3, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(bAceptar3, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(bBorrar3, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(30, Short.MAX_VALUE))
            .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                    .addContainerGap(58, Short.MAX_VALUE)
                    .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
        );

        jPanel9.setBackground(new java.awt.Color(255, 240, 240));
        jPanel9.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Viaje 1", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Lucida Grande", 0, 14))); // NOI18N

        jLabel22.setText("Albarán:");

        Albaran1.setText(" ");

        jLabel27.setText("Vehiculo:");

        comboVehiculo1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Transporter", "Traffic", "Berlingo", "C15" }));
        comboVehiculo1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboVehiculo1ActionPerformed(evt);
            }
        });

        jLabel32.setText("Hora Salida:");

        jLabel38.setText("Hora Llegada:");

        bAceptar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/tick.png"))); // NOI18N
        bAceptar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAceptar1ActionPerformed(evt);
            }
        });

        bEdit1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/edit (1).png"))); // NOI18N
        bEdit1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bEdit1ActionPerformed(evt);
            }
        });

        bBorrar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/editdelete.png"))); // NOI18N
        bBorrar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bBorrar1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel22)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Albaran1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel32)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(horaS1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(jLabel38)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(horaL1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel27)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(comboVehiculo1, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(bAceptar1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(bEdit1, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(bBorrar1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(15, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(bBorrar1, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(horaL1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel27)
                        .addComponent(comboVehiculo1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel22)
                        .addComponent(Albaran1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel32)
                        .addComponent(horaS1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel38))
                    .addComponent(bAceptar1, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bEdit1, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(23, Short.MAX_VALUE))
        );

        jPanel7.setBackground(new java.awt.Color(255, 240, 240));
        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Viaje 5", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Lucida Grande", 0, 14))); // NOI18N

        jLabel26.setText("Albarán:");

        Albaran5.setText(" ");

        jLabel31.setText("Vehiculo:");

        comboVehiculo5.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Transporter", "Traffic", "Berlingo", "C15" }));
        comboVehiculo5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboVehiculo5ActionPerformed(evt);
            }
        });

        jLabel36.setText("Hora Salida:");

        jLabel46.setText("Hora Llegada:");

        bAceptar5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/tick.png"))); // NOI18N
        bAceptar5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAceptar5ActionPerformed(evt);
            }
        });

        bEdit5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/edit (1).png"))); // NOI18N
        bEdit5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bEdit5ActionPerformed(evt);
            }
        });

        bBorrar5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/editdelete.png"))); // NOI18N
        bBorrar5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bBorrar5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel26)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Albaran5, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel36)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(horaS5, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(jLabel46)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(horaL5, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel31)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(comboVehiculo5, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(bAceptar5, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(bEdit5, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(bBorrar5, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(bBorrar5, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bEdit5, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bAceptar5, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(horaL5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel31)
                        .addComponent(comboVehiculo5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel26)
                        .addComponent(Albaran5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel36)
                        .addComponent(horaS5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel46)))
                .addContainerGap(29, Short.MAX_VALUE))
        );

        jLabel8.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel8.setText("ID Parte:");

        jPanel5.setBackground(new java.awt.Color(255, 240, 240));
        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 51, 51)), "Gastos", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 0, 11))); // NOI18N

        jLabel12.setText("Gasoil:");

        jLabel13.setText("Autopista:");

        jLabel14.setText("Dieta:");

        jLabel15.setText("Otros:");

        jLabel16.setText("€");

        jLabel17.setText("€");

        jLabel18.setText("€");

        jLabel19.setText("€");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel14)
                        .addGap(18, 18, 18)
                        .addComponent(tfDieta))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfGasoil, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel16)
                    .addComponent(jLabel19))
                .addGap(58, 58, 58)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel13)
                    .addComponent(jLabel15))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(tfOtros, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
                    .addComponent(tfAutopista))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel17)
                    .addComponent(jLabel18))
                .addContainerGap(34, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(tfGasoil, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13)
                    .addComponent(tfAutopista, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16)
                    .addComponent(jLabel17))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel14)
                            .addComponent(tfDieta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel19))
                        .addGap(23, 23, 23))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tfOtros, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel15)
                            .addComponent(jLabel18))
                        .addGap(19, 19, 19))))
        );

        jLabel9.setText("Incidencias:");

        grupo2.add(radioEditar);
        radioEditar.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        radioEditar.setText("Editar");
        radioEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radioEditarActionPerformed(evt);
            }
        });

        tArea1.setColumns(20);
        tArea1.setRows(5);
        jScrollPane1.setViewportView(tArea1);

        jLabel20.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel20.setText("Estado:");

        grupo2.add(radioBorrar);
        radioBorrar.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        radioBorrar.setText("Borrar");
        radioBorrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radioBorrarActionPerformed(evt);
            }
        });

        labelEstado.setForeground(new java.awt.Color(255, 51, 51));
        labelEstado.setText("-");

        comboIDParte.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                comboIDParteItemStateChanged(evt);
            }
        });

        jPanel4.setBackground(new java.awt.Color(255, 240, 240));
        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 51, 51)), "Kilometros", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 0, 11))); // NOI18N

        jLabel10.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel10.setText("Km Inicio:");

        jLabel11.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel11.setText("Km Fin:");

        jLabel21.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel21.setText("Km Total:");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10)
                    .addComponent(jLabel11))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(tfkmi, javax.swing.GroupLayout.DEFAULT_SIZE, 90, Short.MAX_VALUE)
                    .addComponent(tfkmf))
                .addGap(30, 30, 30)
                .addComponent(jLabel21)
                .addGap(18, 18, 18)
                .addComponent(tfkmt, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(22, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfkmi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(tfkmf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(23, Short.MAX_VALUE))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21)
                    .addComponent(tfkmt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(49, 49, 49))
        );

        jLabel37.setFont(new java.awt.Font("Verdana", 0, 12)); // NOI18N
        jLabel37.setText("Validado:");

        labelValidado.setForeground(new java.awt.Color(102, 255, 102));
        labelValidado.setText("--");

        bAceptar.setText("Aceptar");
        bAceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAceptarActionPerformed(evt);
            }
        });

        jPanel8.setBackground(new java.awt.Color(255, 240, 240));
        jPanel8.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Viaje 2", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Lucida Grande", 0, 14))); // NOI18N

        jLabel23.setText("Albarán:");

        Albaran2.setText(" ");

        jLabel28.setText("Vehiculo:");

        comboVehiculo2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Transporter", "Traffic", "Berlingo", "C15" }));
        comboVehiculo2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboVehiculo2ActionPerformed(evt);
            }
        });

        jLabel33.setText("Hora Salida:");

        jLabel39.setText("Hora Llegada:");

        bAceptar2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/tick.png"))); // NOI18N
        bAceptar2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAceptar2ActionPerformed(evt);
            }
        });

        bEdit2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/edit (1).png"))); // NOI18N
        bEdit2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bEdit2ActionPerformed(evt);
            }
        });

        bBorrar2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/editdelete.png"))); // NOI18N
        bBorrar2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bBorrar2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel23)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Albaran2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel33)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(horaS2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(jLabel39)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(horaL2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel28)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(comboVehiculo2, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(bAceptar2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(bEdit2, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(bBorrar2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(bBorrar2, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bEdit2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(horaL2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel28)
                            .addComponent(comboVehiculo2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel23)
                            .addComponent(Albaran2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel33)
                            .addComponent(horaS2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel39))
                        .addComponent(bAceptar2, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(28, Short.MAX_VALUE))
        );

        bSalir.setText("Salir");
        bSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bSalirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(167, 167, 167)
                        .addComponent(bCerrarValidar)
                        .addGap(64, 64, 64)
                        .addComponent(bAceptar)
                        .addGap(840, 840, 840)
                        .addComponent(bSalir))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel12Layout.createSequentialGroup()
                                .addGap(51, 51, 51)
                                .addComponent(jLabel8)
                                .addGap(18, 18, 18)
                                .addComponent(comboIDParte, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(37, 37, 37)
                                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel12Layout.createSequentialGroup()
                                        .addComponent(jLabel37)
                                        .addGap(18, 18, 18)
                                        .addComponent(labelValidado))
                                    .addGroup(jPanel12Layout.createSequentialGroup()
                                        .addComponent(jLabel20)
                                        .addGap(18, 18, 18)
                                        .addComponent(labelEstado, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(radioBorrar)
                                    .addComponent(radioEditar)))
                            .addGroup(jPanel12Layout.createSequentialGroup()
                                .addGap(68, 68, 68)
                                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel12Layout.createSequentialGroup()
                                .addGap(34, 34, 34)
                                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jPanel12Layout.createSequentialGroup()
                                        .addComponent(jLabel9)
                                        .addGap(18, 18, 18)
                                        .addComponent(jScrollPane1))
                                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(64, 64, 64)
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jPanel7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel8, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel10, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(22, Short.MAX_VALUE))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel12Layout.createSequentialGroup()
                                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel20)
                                    .addComponent(labelEstado)
                                    .addComponent(radioEditar))
                                .addGap(8, 8, 8)
                                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel37)
                                    .addComponent(labelValidado)
                                    .addComponent(radioBorrar))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(comboIDParte, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel8))
                                .addGap(27, 27, 27)))
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(47, 47, 47)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(55, 55, 55)
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(bCerrarValidar)
                            .addComponent(bAceptar))
                        .addGap(30, 30, 30))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(27, 27, 27)
                        .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 42, Short.MAX_VALUE)
                        .addComponent(bSalir)
                        .addGap(40, 40, 40))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * Llena el combo de DNIs segun el centro
     * @param evt 
     */
    private void comboCentroItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_comboCentroItemStateChanged
        comboDNI.removeAllItems();
        llenarComboDNI();
    }//GEN-LAST:event_comboCentroItemStateChanged

    private void comboDNIItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_comboDNIItemStateChanged
        try
        {
            if("".equals(comboDNI.getSelectedItem().toString())){
                tfNombre.setText("");
                tfApellidos.setText("");
                
                radioTodos.setEnabled(false);
                radioFechas.setEnabled(false);
            
                bVisualizar.setEnabled(false);
            }
            tfNombre.setText(Controlador.Main.datosTrabajador(comboDNI.getSelectedItem().toString()).getNombre());
            tfApellidos.setText(Controlador.Main.datosTrabajador(comboDNI.getSelectedItem().toString()).getApellido1());
            radioTodos.setEnabled(true);
            radioFechas.setEnabled(true);
            
            bVisualizar.setEnabled(true);
            
            
        }
        catch(Exception e)
        {
               JOptionPane.showMessageDialog(this, "Ha ocurrido el siguiente error convirtiendo el nombre " + e.getMessage() );     
        }
    }//GEN-LAST:event_comboDNIItemStateChanged

    private void radioTodosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radioTodosActionPerformed
        dateChooserCombo1.setEnabled(false);
        dateChooserCombo2.setEnabled(false);
    }//GEN-LAST:event_radioTodosActionPerformed

    private void radioFechasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radioFechasActionPerformed
        dateChooserCombo1.setEnabled(true);
        dateChooserCombo2.setEnabled(true);
    }//GEN-LAST:event_radioFechasActionPerformed

    /**
     * Visualiza los partes que necesitas y te selecciona el primero por defecto si es que hay
     * @param evt 
     */
    private void bVisualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bVisualizarActionPerformed
        comboIDParte.setEnabled(true);
        try
        {
            comboIDParte.removeAllItems();
            if(radioTodos.isSelected() == true){
                llenarComboIDParte();
            }
            else if(radioFechas.isSelected() == true){
                llenarComboIDParteFechas();
            }
            
        if(comboIDParte.getItemCount() > 0){
            comboIDParte.setSelectedIndex(0); 
        }
            
           
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(this, "Ha ocurrido el siguiente error buscando partes: " + e.getMessage() );   
        }
    }//GEN-LAST:event_bVisualizarActionPerformed

    /**
     * Cierra los partes o los valida en funcion del tipo de trabajador que eres y de si se puede o no
     * @param evt 
     */
    private void bCerrarValidarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCerrarValidarActionPerformed
        if("L".equals(Controlador.Main.getTipologged())){
            if("Cerrado".equals(Controlador.Main.getP().getEstado())){
                JOptionPane.showMessageDialog(this, "El parte " + comboIDParte.getSelectedItem().toString() + " ya estaba cerrado");
            }
            else
            {
            Controlador.Main.cerrarParte(comboIDParte.getSelectedItem().toString());
            JOptionPane.showMessageDialog(this, "Se ha cerrado el parte " + comboIDParte.getSelectedItem().toString());
            Controlador.Main.buscarParteID(comboIDParte.getSelectedItem().toString());
            llenarCampos();
            }
        }
        if("A".equals(Controlador.Main.getTipologged())){
            if("Cerrado".equals(Controlador.Main.getP().getEstado())){
                if("Si".equals(Controlador.Main.getP().getValidado())){
                    JOptionPane.showMessageDialog(this, "El parte " + comboIDParte.getSelectedItem().toString() + " ya estaba validado");
                }
                else
                {
                   Controlador.Main.validarParte(comboIDParte.getSelectedItem().toString());
                   JOptionPane.showMessageDialog(this, "Se ha validado el parte " + comboIDParte.getSelectedItem().toString());
                   Controlador.Main.buscarParteID(comboIDParte.getSelectedItem().toString());
                    llenarCampos();
                }
            }
            else
            {
                JOptionPane.showMessageDialog(this, "No se puede validar un parte que no está cerrado, hay que cerrarlo antes");
            }
        }
        
            
    }//GEN-LAST:event_bCerrarValidarActionPerformed

    private void comboVehiculo1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboVehiculo1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboVehiculo1ActionPerformed

    private void comboVehiculo2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboVehiculo2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboVehiculo2ActionPerformed

    private void comboVehiculo3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboVehiculo3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboVehiculo3ActionPerformed

    private void comboVehiculo5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboVehiculo5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboVehiculo5ActionPerformed

    /**
     * Permite editar el parte o los viajes
     * @param evt 
     */
    private void radioEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radioEditarActionPerformed
        if("Cerrado".equals(Controlador.Main.getP().getEstado())){
            JOptionPane.showMessageDialog(this, "No puedes editar un parte que ya está cerrado");
        }
        else
        {   
            activarCamposParte();
            bEdit1.setEnabled(true);
            bBorrar1.setEnabled(true);
            bEdit2.setEnabled(true);
            bBorrar2.setEnabled(true);
            bEdit3.setEnabled(true);
            bBorrar3.setEnabled(true);
            bEdit4.setEnabled(true);
            bBorrar4.setEnabled(true);
            bEdit5.setEnabled(true);
            bBorrar5.setEnabled(true);
            bAceptar.setEnabled(true); 
        }
        
    }//GEN-LAST:event_radioEditarActionPerformed

    private void radioBorrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radioBorrarActionPerformed
        if("Cerrado".equals(Controlador.Main.getP().getEstado())){
            JOptionPane.showMessageDialog(this, "No puedes borrar un parte que ya está cerrado");
        }
        else
        { 
            desactivarCamposParte();
            bAceptar.setEnabled(true);
        }
    }//GEN-LAST:event_radioBorrarActionPerformed

    /**
     * Sale a la ventana principal
     * @param evt 
     */
    private void bSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bSalirActionPerformed
        this.dispose();
        Controlador.Main.mostrarVentanaPrincipal();
    }//GEN-LAST:event_bSalirActionPerformed

    private void comboIDParteItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_comboIDParteItemStateChanged
        radioBorrar.setEnabled(true);
        radioEditar.setEnabled(true);
        Controlador.Main.buscarParteID(comboIDParte.getSelectedItem().toString());
        llenarCampos();
        vaciarCamposViaje(Albaran1, horaS1, horaL1, comboVehiculo1);
        vaciarCamposViaje(Albaran2, horaS2, horaL2, comboVehiculo2);
        vaciarCamposViaje(Albaran3, horaS3, horaL3, comboVehiculo3);
        vaciarCamposViaje(Albaran4, horaS4, horaL4, comboVehiculo4);
        vaciarCamposViaje(Albaran5, horaS5, horaL5, comboVehiculo5);
        llenarViajes(comboIDParte.getSelectedItem().toString());
    }//GEN-LAST:event_comboIDParteItemStateChanged

    private void comboVehiculo4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboVehiculo4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboVehiculo4ActionPerformed

    private void horaS4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_horaS4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_horaS4ActionPerformed

    private void bAceptar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAceptar1ActionPerformed
        try{
            if("".equals(Albaran1.getText())){
                Controlador.Main.insertarViaje(horaS1.getText(), horaL1.getText(), comboIDParte.getSelectedItem().toString(), comboVehiculo1.getSelectedItem().toString());
                JOptionPane.showMessageDialog(this, "Viaje insertado con exito");
                llenarViajes(comboIDParte.getSelectedItem().toString());
            }
            else
            {
                Controlador.Main.actualizarViaje(horaS1.getText(), horaL1.getText(), comboVehiculo1.getSelectedItem().toString(), Albaran1.getText());
                JOptionPane.showMessageDialog(this, "Viaje modificado con exito");
            }
            desactivarCamposViaje(Albaran1, horaS1, horaL1, comboVehiculo1, bAceptar1);
        }
        catch (Exception e){
            JOptionPane.showMessageDialog(this, "No se pudo insertar/modificar el viaje " + e.getMessage());
        }
    }//GEN-LAST:event_bAceptar1ActionPerformed

    private void bAceptar2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAceptar2ActionPerformed
        try{
            if("".equals(Albaran2.getText())){
                Controlador.Main.insertarViaje(horaS2.getText(), horaL2.getText(), comboIDParte.getSelectedItem().toString(), comboVehiculo2.getSelectedItem().toString());
                JOptionPane.showMessageDialog(this, "Viaje insertado con exito");
                llenarViajes(comboIDParte.getSelectedItem().toString());
            }
            else
            {
                Controlador.Main.actualizarViaje(horaS2.getText(), horaL2.getText(), comboVehiculo2.getSelectedItem().toString(), Albaran2.getText());
                JOptionPane.showMessageDialog(this, "Viaje modificado con exito");
            }
            desactivarCamposViaje(Albaran2, horaS2, horaL2, comboVehiculo2, bAceptar2);
        }
        catch (Exception e){
            JOptionPane.showMessageDialog(this, "No se pudo insertar/modificar el viaje " + e.getMessage());
        }
    }//GEN-LAST:event_bAceptar2ActionPerformed

    private void bAceptar3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAceptar3ActionPerformed
        try{
            if("".equals(Albaran3.getText())){
                Controlador.Main.insertarViaje(horaS3.getText(), horaL3.getText(), comboIDParte.getSelectedItem().toString(), comboVehiculo3.getSelectedItem().toString());
                JOptionPane.showMessageDialog(this, "Viaje insertado con exito");
                llenarViajes(comboIDParte.getSelectedItem().toString());
            }
            else
            {
                Controlador.Main.actualizarViaje(horaS3.getText(), horaL3.getText(), comboVehiculo3.getSelectedItem().toString(), Albaran3.getText());
                JOptionPane.showMessageDialog(this, "Viaje modificado con exito");
            }
            desactivarCamposViaje(Albaran3, horaS3, horaL3, comboVehiculo3, bAceptar3);
        }
        catch (Exception e){
            JOptionPane.showMessageDialog(this, "No se pudo insertar/modificar el viaje " + e.getMessage());
        }
    }//GEN-LAST:event_bAceptar3ActionPerformed

    private void bAceptar4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAceptar4ActionPerformed
        try{
            if("".equals(Albaran4.getText())){
                Controlador.Main.insertarViaje(horaS4.getText(), horaL4.getText(), comboIDParte.getSelectedItem().toString(), comboVehiculo4.getSelectedItem().toString());
                JOptionPane.showMessageDialog(this, "Viaje insertado con exito");
                llenarViajes(comboIDParte.getSelectedItem().toString());
            }
            else
            {
                Controlador.Main.actualizarViaje(horaS4.getText(), horaL4.getText(), comboVehiculo4.getSelectedItem().toString(), Albaran4.getText());
                JOptionPane.showMessageDialog(this, "Viaje modificado con exito");
            }
            desactivarCamposViaje(Albaran4, horaS4, horaL4, comboVehiculo4, bAceptar4);
        }
        catch (Exception e){
            JOptionPane.showMessageDialog(this, "No se pudo insertar/modificar el viaje " + e.getMessage());
        }
    }//GEN-LAST:event_bAceptar4ActionPerformed

    private void bAceptar5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAceptar5ActionPerformed
        try{
            if("".equals(Albaran5.getText())){
                Controlador.Main.insertarViaje(horaS5.getText(), horaL5.getText(), comboIDParte.getSelectedItem().toString(), comboVehiculo5.getSelectedItem().toString());
                JOptionPane.showMessageDialog(this, "Viaje insertado con exito");
                llenarViajes(comboIDParte.getSelectedItem().toString());
            }
            else
            {
                Controlador.Main.actualizarViaje(horaS5.getText(), horaL5.getText(), comboVehiculo5.getSelectedItem().toString(), Albaran5.getText());
                JOptionPane.showMessageDialog(this, "Viaje modificado con exito");
            }
            desactivarCamposViaje(Albaran5, horaS5, horaL5, comboVehiculo5, bAceptar5);
        }
        catch (Exception e){
            JOptionPane.showMessageDialog(this, "No se pudo insertar/modificar el viaje " + e.getMessage());
        }
    }//GEN-LAST:event_bAceptar5ActionPerformed

    private void bEdit1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bEdit1ActionPerformed
        activarCamposViaje(horaS1, horaL1, comboVehiculo1, bAceptar1);
    }//GEN-LAST:event_bEdit1ActionPerformed

    private void bEdit2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bEdit2ActionPerformed
        activarCamposViaje(horaS2, horaL2, comboVehiculo2, bAceptar2);
    }//GEN-LAST:event_bEdit2ActionPerformed

    private void bEdit3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bEdit3ActionPerformed
        activarCamposViaje(horaS3, horaL3, comboVehiculo3, bAceptar3);
    }//GEN-LAST:event_bEdit3ActionPerformed

    private void bEdit4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bEdit4ActionPerformed
        activarCamposViaje(horaS4, horaL4, comboVehiculo4, bAceptar4);
    }//GEN-LAST:event_bEdit4ActionPerformed

    private void bEdit5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bEdit5ActionPerformed
        activarCamposViaje(horaS5, horaL5, comboVehiculo5, bAceptar5);
    }//GEN-LAST:event_bEdit5ActionPerformed

    private void bBorrar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bBorrar1ActionPerformed
        int r1 = JOptionPane.showConfirmDialog(this, "¿Estas seguro de querer borrar al viaje?");
            
            if (JOptionPane.OK_OPTION == r1){
            JOptionPane.showMessageDialog(this, "Se ha borrado el viaje"); 
            Controlador.Main.borrarViaje(Albaran1.getText());
            vaciarCamposViaje(Albaran1, horaS1, horaL1, comboVehiculo1);
            desactivarCamposViaje(Albaran1, horaS1, horaL1, comboVehiculo1, bAceptar1);
          }
           else if(JOptionPane.NO_OPTION == r1){
                JOptionPane.showMessageDialog(this, "Vale... no borro nada...");
          }
    }//GEN-LAST:event_bBorrar1ActionPerformed

    private void bBorrar2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bBorrar2ActionPerformed
       int r1 = JOptionPane.showConfirmDialog(this, "¿Estas seguro de querer borrar al viaje?");
            
            if (JOptionPane.OK_OPTION == r1){
            JOptionPane.showMessageDialog(this, "Se ha borrado el viaje"); 
            Controlador.Main.borrarViaje(Albaran2.getText());
            vaciarCamposViaje(Albaran2, horaS2, horaL2, comboVehiculo2);
            desactivarCamposViaje(Albaran2, horaS2, horaL2, comboVehiculo2, bAceptar2);
          }
           else if(JOptionPane.NO_OPTION == r1){
                JOptionPane.showMessageDialog(this, "Vale... no borro nada...");
          }
    }//GEN-LAST:event_bBorrar2ActionPerformed

    private void bBorrar3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bBorrar3ActionPerformed
        int r1 = JOptionPane.showConfirmDialog(this, "¿Estas seguro de querer borrar al viaje?");
            
            if (JOptionPane.OK_OPTION == r1){
            JOptionPane.showMessageDialog(this, "Se ha borrado el viaje"); 
            Controlador.Main.borrarViaje(Albaran3.getText());
            vaciarCamposViaje(Albaran3, horaS3, horaL3, comboVehiculo3);
            desactivarCamposViaje(Albaran3, horaS3, horaL3, comboVehiculo3, bAceptar3);
          }
           else if(JOptionPane.NO_OPTION == r1){
                JOptionPane.showMessageDialog(this, "Vale... no borro nada...");
          }
    }//GEN-LAST:event_bBorrar3ActionPerformed

    private void bBorrar4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bBorrar4ActionPerformed
        int r1 = JOptionPane.showConfirmDialog(this, "¿Estas seguro de querer borrar al viaje?");
            
            if (JOptionPane.OK_OPTION == r1){
            JOptionPane.showMessageDialog(this, "Se ha borrado el viaje"); 
            Controlador.Main.borrarViaje(Albaran4.getText());
            vaciarCamposViaje(Albaran4, horaS4, horaL4, comboVehiculo4);
            desactivarCamposViaje(Albaran4, horaS4, horaL4, comboVehiculo4, bAceptar4);
          }
           else if(JOptionPane.NO_OPTION == r1){
                JOptionPane.showMessageDialog(this, "Vale... no borro nada...");
          }
    }//GEN-LAST:event_bBorrar4ActionPerformed

    private void bBorrar5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bBorrar5ActionPerformed
        int r1 = JOptionPane.showConfirmDialog(this, "¿Estas seguro de querer borrar al viaje?");
            
            if (JOptionPane.OK_OPTION == r1){
            JOptionPane.showMessageDialog(this, "Se ha borrado el viaje"); 
            Controlador.Main.borrarViaje(Albaran5.getText());
            vaciarCamposViaje(Albaran5, horaS5, horaL5, comboVehiculo5);
            desactivarCamposViaje(Albaran5, horaS5, horaL5, comboVehiculo5, bAceptar5);
          }
           else if(JOptionPane.NO_OPTION == r1){
                JOptionPane.showMessageDialog(this, "Vale... no borro nada...");
          }
    }//GEN-LAST:event_bBorrar5ActionPerformed

    private void comboDNIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboDNIActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboDNIActionPerformed

    private void bNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bNuevoActionPerformed
        Controlador.Main.mostrarVentanaNuevoParte();
    }//GEN-LAST:event_bNuevoActionPerformed

    /**
     * Aceptar el editar o borrar el parte entero
     * @param evt 
     */
    private void bAceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAceptarActionPerformed
        if(radioBorrar.isSelected()){
            Controlador.Main.borrarParte(comboIDParte.getSelectedItem().toString()); 
            JOptionPane.showMessageDialog(this, "Se ha borrado el parte : " + comboIDParte.getSelectedItem().toString());
            vaciarCamposParte();
            vaciarCamposViaje(Albaran1, horaS1, horaL1, comboVehiculo1);
            vaciarCamposViaje(Albaran2, horaS2, horaL2, comboVehiculo2);
            vaciarCamposViaje(Albaran3, horaS3, horaL3, comboVehiculo3);
            vaciarCamposViaje(Albaran4, horaS4, horaL4, comboVehiculo4);
            vaciarCamposViaje(Albaran5, horaS5, horaL5, comboVehiculo5);
        }
        else if(radioEditar.isSelected()){
            Controlador.Main.actualizarParte(Float.parseFloat(tfkmi.getText()), Float.parseFloat(tfkmf.getText()), Float.parseFloat(tfGasoil.getText()), Float.parseFloat(tfDieta.getText()), Float.parseFloat(tfAutopista.getText()), Float.parseFloat(tfOtros.getText()), tArea1.getText(), comboIDParte.getSelectedItem().toString());
            JOptionPane.showMessageDialog(this, "Se ha modificado el parte : " + comboIDParte.getSelectedItem().toString());
        }
    }//GEN-LAST:event_bAceptarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaBuscarParte.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaBuscarParte.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaBuscarParte.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaBuscarParte.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaBuscarParte().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Albaran1;
    private javax.swing.JTextField Albaran2;
    private javax.swing.JTextField Albaran3;
    private javax.swing.JTextField Albaran4;
    private javax.swing.JTextField Albaran5;
    private javax.swing.JButton bAceptar;
    private javax.swing.JButton bAceptar1;
    private javax.swing.JButton bAceptar2;
    private javax.swing.JButton bAceptar3;
    private javax.swing.JButton bAceptar4;
    private javax.swing.JButton bAceptar5;
    private javax.swing.JButton bBorrar1;
    private javax.swing.JButton bBorrar2;
    private javax.swing.JButton bBorrar3;
    private javax.swing.JButton bBorrar4;
    private javax.swing.JButton bBorrar5;
    private javax.swing.JButton bCerrarValidar;
    private javax.swing.JButton bEdit1;
    private javax.swing.JButton bEdit2;
    private javax.swing.JButton bEdit3;
    private javax.swing.JButton bEdit4;
    private javax.swing.JButton bEdit5;
    private javax.swing.JButton bNuevo;
    private javax.swing.JButton bSalir;
    private javax.swing.JButton bVisualizar;
    private javax.swing.JComboBox<String> comboCentro;
    private javax.swing.JComboBox<String> comboDNI;
    private javax.swing.JComboBox<String> comboIDParte;
    private javax.swing.JComboBox<String> comboVehiculo1;
    private javax.swing.JComboBox<String> comboVehiculo2;
    private javax.swing.JComboBox<String> comboVehiculo3;
    private javax.swing.JComboBox<String> comboVehiculo4;
    private javax.swing.JComboBox<String> comboVehiculo5;
    private datechooser.beans.DateChooserCombo dateChooserCombo1;
    private datechooser.beans.DateChooserCombo dateChooserCombo2;
    private javax.swing.ButtonGroup grupo1;
    private javax.swing.ButtonGroup grupo2;
    private javax.swing.JTextField horaL1;
    private javax.swing.JTextField horaL2;
    private javax.swing.JTextField horaL3;
    private javax.swing.JTextField horaL4;
    private javax.swing.JTextField horaL5;
    private javax.swing.JTextField horaS1;
    private javax.swing.JTextField horaS2;
    private javax.swing.JTextField horaS3;
    private javax.swing.JTextField horaS4;
    private javax.swing.JTextField horaS5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel labelEstado;
    private javax.swing.JLabel labelValidado;
    private javax.swing.JRadioButton radioBorrar;
    private javax.swing.JRadioButton radioEditar;
    private javax.swing.JRadioButton radioFechas;
    private javax.swing.JRadioButton radioTodos;
    private javax.swing.JTextArea tArea1;
    private javax.swing.JTextField tfApellidos;
    private javax.swing.JTextField tfAutopista;
    private javax.swing.JTextField tfDieta;
    private javax.swing.JTextField tfGasoil;
    private javax.swing.JTextField tfNombre;
    private javax.swing.JTextField tfOtros;
    private javax.swing.JTextField tfkmf;
    private javax.swing.JTextField tfkmi;
    private javax.swing.JTextField tfkmt;
    // End of variables declaration//GEN-END:variables
}
